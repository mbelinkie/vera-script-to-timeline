# #125 handoff — S03 Integrated Authoring r29

Review revision: `S03 Integrated Authoring r29` (2026-11-15). Prototype code unchanged by the handoff pass.

- `S03 Integrated Authoring r29.dc.html` — editable source, byte-identical to the project-root r29.
- `support.js` — runtime the source loads (`./support.js`). Keep it beside the source. React, ReactDOM and Babel load from unpkg.
- `S03 Integrated Authoring r29 - export.html` — self-contained single-file export of the same build.

Documents: `S03 design decisions.md` (D187–D193 and the handoff entry), `S03 spec.md`, `Implementation backlog.md` (item 44).

Open for implementation (one production range-edit issue): Folded Letter bracket drag removes On Camera with Undo disabled; a one-word shortening moves the neighbouring still's start; Amber Lantern and Paper Lanterns confirm creates an Undo entry while the brackets stay put. Awaiting Matthew's sign-off.
