// Scripted checks for S03 Integrated Authoring r30 (Timeline #642). Open the pilot (ideally with #embed=1 so the frame sits at 0,0),
// then press the harness button "Run scripted checks", or in the console: import("./r30-checks.js").then(m => m.runAll())
// Every check is SCRIPTED: synthetic PointerEvent/MouseEvent/KeyboardEvent dispatch, carets via caretRangeFromPoint.
// They are not a physical mouse, trackpad or keyboard. P = pointer flow, K = keyboard flow.
const wait = (ms) => new Promise(r => setTimeout(r, ms));
const C = () => window.__q30C;
const Q = () => "The west gauge is reporting values that do not match the water.";
const SP = () => "“" + Q() + "”"; // spoken form: one outer pair of curly double quotes
function ev(el, type, x, y, extra) {
  const o = Object.assign({ bubbles: true, cancelable: true, composed: true, clientX: x, clientY: y, button: 0, buttons: /up$/.test(type) ? 0 : 1, pointerId: 1, pointerType: "mouse", isPrimary: true, view: window }, extra || {});
  (el || document.body).dispatchEvent(/^pointer/.test(type) ? new PointerEvent(type, o) : new MouseEvent(type, o));
}
const at = (x, y) => document.elementFromPoint(x, y) || document.body;
function key(k, o, el) { (el || document.activeElement || document.body).dispatchEvent(new KeyboardEvent("keydown", Object.assign({ key: k, bubbles: true, cancelable: true }, o || {}))); }
const cmdShiftF = () => key("f", { code: "KeyF", metaKey: true, shiftKey: true }, document.activeElement && document.activeElement.closest && document.activeElement.closest("[data-prose]") ? document.activeElement : (C().q30Prose() || document.body));
const pid = () => C().q30Pid();
const rowOf = (p) => C().q30RowOf(p);
const words = (p) => String((rowOf(p) || {}).words || "");
const domText = (p) => { const t = C().q30Toks(p); return t ? t.toks.map(x => x.text).join(" ") : ""; };
const q30Vis = (p) => ((rowOf(p) || {}).visuals || []).filter(v => /^q30[pb]\d/.test(v.id));
const undoN = () => (C().state.undo || []).length;
const undoLabel = () => ((C().state.undo || [])[0] || {}).label || "";
const tok = (p, text, side) => { C().q30Scroll(); const t = C().q30Toks(p).toks.find(x => x.text === text); const r = t.rects[side === "start" ? 0 : t.rects.length - 1]; return { x: side === "start" ? r.left + 1 : r.right, y: (r.top + r.bottom) / 2, r }; };
function clickCaret(x, y) { const el = at(x, y); ev(el, "pointerdown", x, y); ev(el, "mousedown", x, y); const cr = document.caretRangeFromPoint(x, y), pe = el.closest && el.closest("[data-prose]");
  if (pe && cr) { pe.focus({ preventScroll: true }); const s = getSelection(); s.removeAllRanges(); s.addRange(cr); } ev(el, "pointerup", x, y); ev(el, "mouseup", x, y); ev(el, "click", x, y); }
function clickBtn(b) { reveal(b); const r = b.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2; ev(b, "pointerdown", x, y); ev(b, "mousedown", x, y); b.focus(); ev(b, "pointerup", x, y); ev(b, "mouseup", x, y); b.click(); }
function handSelect(a, b) { const el = at(a.x, a.y), s = getSelection(); ev(el, "pointerdown", a.x, a.y); ev(el, "mousedown", a.x, a.y); const pe = el.closest("[data-prose]"); pe.focus({ preventScroll: true });
  const ra = document.caretRangeFromPoint(a.x, a.y); s.removeAllRanges(); s.collapse(ra.startContainer, ra.startOffset);
  for (let i = 1; i <= 8; i++) { const x = a.x + (b.x - a.x) * i / 8, y = a.y + (b.y - a.y) * i / 8, e2 = at(x, y); ev(e2, "pointermove", x, y); ev(e2, "mousemove", x, y); const rb = document.caretRangeFromPoint(x, y); s.extend(rb.startContainer, rb.startOffset); }
  const e3 = at(b.x, b.y); ev(e3, "pointerup", b.x, b.y); ev(e3, "mouseup", b.x, b.y); return s.toString(); }
const selectSentence1 = () => { C().q30Scroll(); const p = pid(); return handSelect(tok(p, "Across", "start"), { x: tok(p, "gauge.", "end").x + 1, y: tok(p, "gauge.", "end").y }); };
let dragAt = null;
function reveal(el) { let p = el && el.parentElement; while (p && p !== document.body) { const cs = getComputedStyle(p); if (/(auto|scroll)/.test(cs.overflowY) && p.scrollHeight > p.clientHeight) { const r = el.getBoundingClientRect(), pr = p.getBoundingClientRect(); if (r.top < pr.top + 4 || r.bottom > pr.bottom - 4) p.scrollTop += r.top - pr.top - 40; return; } p = p.parentElement; } }
function dragStart(to, qid) { const card = document.querySelector(qid ? '[data-q30excerpt="' + qid + '"]' : "[data-q30excerpt]"); reveal(card); const R = card.getBoundingClientRect(), x0 = R.left + 40, y0 = R.top + 8, el = at(x0, y0);
  ev(el, "pointerdown", x0, y0); ev(el, "mousedown", x0, y0); for (let i = 1; i <= 20; i++) { const x = x0 + (to.x - x0) * i / 20, y = y0 + (to.y - y0) * i / 20; ev(at(x, y), "pointermove", x, y); ev(at(x, y), "mousemove", x, y); } dragAt = to; }
function dragMove(x, y) { ev(at(x, y), "pointermove", x, y); ev(at(x, y), "mousemove", x, y); dragAt = { x, y }; }
function dragDrop() { const e = at(dragAt.x, dragAt.y); ev(e, "pointerup", dragAt.x, dragAt.y); ev(e, "mouseup", dragAt.x, dragAt.y); }
const overlap = (a, b) => a && b && a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
function tagClear() { const tg = document.querySelector("[data-q30tag]"); if (!tg) return false; const T = tg.getBoundingClientRect();
  return ![...document.querySelectorAll("[data-prose] [data-w]")].some(w => [...w.getClientRects()].some(r => overlap(T, r))); }
function dlgClear() { const d = document.querySelector("[data-q30dlg]"), c = document.querySelector("[data-q30card]"); if (!d || !c) return false; return !overlap(d.getBoundingClientRect(), c.getBoundingClientRect()); }
async function undo() { const b = [...document.querySelectorAll("button")].find(x => /^Undo /.test(x.getAttribute("aria-label") || "")); if (b) clickBtn(b); await wait(350); }
const focusIs = (sel) => !!(document.activeElement && document.activeElement.matches && document.activeElement.matches(sel));
const liveText = () => (document.querySelector("[data-q30live]") || {}).textContent || "";

export async function runAll(opts) {
  opts = opts || {}; const out = [], vp = () => { const f = document.querySelector("[data-frame]"); return f ? Math.round(f.getBoundingClientRect().width) + "×" + Math.round(f.getBoundingClientRect().height) : "?"; };
  window.__r30bResults = out; const res = (id, kind, label, pass, detail) => { out.push({ size: vp(), id, kind, label, pass: !!pass, detail: detail || "" }); };
  const sizes = opts.sizes || ["1280 × 800", "1024 × 768", "1280 × 800"];
  for (let si = 0; si < sizes.length; si++) {
    const want = /^1024/.test(sizes[si]); if (!!C().state.compact !== want) { C().setState({ compact: want }); await wait(1800); } // same state the harness 1280/1024 buttons set
    C().q30Scroll(); await wait(500); const tagPre = si === 2 ? "after resize · " : "";
    const p = pid(); const w0 = words(p), d0 = domText(p);

    // P1 blank row: Add row → caret in blank narration → Place in script… → Enter → one Undo restores the blank row
    { const row = rowOf(p), n = (C().state.pilotSeq || 0) + 1; C().pilotAddRow(row.logical || row.id); await wait(150); C().r11FocusProse("nr" + n, false); await wait(400); // same steps as the divider's Add row button (addPick)
      const bp = document.activeElement && document.activeElement.hasAttribute && document.activeElement.hasAttribute("data-blankprose") ? document.activeElement : null, bpid = bp && bp.getAttribute("data-prose");
      res("P1a", "scripted pointer", tagPre + "Add row focuses blank narration (divider Add row handler called directly; hover not scripted)", !!bp);
      await wait(120); clickBtn(document.querySelector("[data-q30place]")); await wait(300);
      const dl = document.querySelector("[data-q30dlg]");
      res("P1b", "scripted pointer", tagPre + "Place in script… offers Insert quote in the new row, focus on Insert quote, dialog clear of the quote card", dl && /Insert quote/.test(dl.innerText) && /new blank row/.test(dl.innerText) && focusIs("[data-q30go]") && dlgClear(), dl ? dl.innerText.replace(/\n/g, " / ").slice(0, 160) : "no dialog");
      const n0 = undoN(); key("Enter"); await wait(400);
      const v = q30Vis(bpid), pic = v.find(x => /^q30p/.test(x.id)), box = v.find(x => /^q30b/.test(x.id)), line = document.querySelector("[data-q30qbline]");
      res("P1c", "scripted keyboard", tagPre + "Enter inserts once: narration is the quote in one pair of curly quotes, box keeps its own text, picture and box cover all 12 words", words(bpid) === SP() && domText(bpid) === SP() && box && box.customText === Q() && line && line.textContent === "“" + Q() + "”" && pic && pic.cue === 0 && box && box.cue === 0 && box.outAt === 11 && undoN() === n0 + 1 && !document.querySelector("[data-q30dlg]"), "words=" + words(bpid).slice(0, 30) + " box=" + (box && box.cue + "–" + box.outAt) + " undo+" + (undoN() - n0));
      await undo(); const rb = rowOf(bpid);
      res("P1d", "scripted pointer", tagPre + "One Undo restores the blank row and clears the announcement", rb && !rb.words && (rb.visuals || []).some(x => x.kind === "undefined") && !q30Vis(bpid).length && !liveText(), "live=" + liveText().slice(0, 40));
      await undo(); res("P1e", "scripted pointer", tagPre + "cleanup: second Undo removes the added row", !rowOf(bpid)); }

    // P2 full-sentence drag attach, narration identical
    { const s1 = selectSentence1(); await wait(150); dragStart(tok(p, "keeper", "end")); await wait(250);
      const tg = document.querySelector("[data-q30tag]"), bar = document.querySelector("[data-cmt-selbar]");
      res("P2a", "scripted pointer", tagPre + "while dragging: outline on the selected sentence, 'Attach quote · narration unchanged' clear of the text, selection kept, toolbar hidden", tg && tg.textContent === "Attach quote · narration unchanged" && tagClear() && getSelection().toString() === s1 && (!bar || bar.style.visibility === "hidden") && document.querySelectorAll("[data-q30ov]").length >= 2, "sel=" + getSelection().toString().slice(0, 30));
      const n0 = undoN(); dragDrop(); await wait(450); const v = q30Vis(p), box = v.find(x => /^q30b/.test(x.id)), pic = v.find(x => /^q30p/.test(x.id));
      res("P2b", "scripted pointer", tagPre + "drop attaches both visuals to words 1–13; narration identical in data and on screen (no quotation marks added); one Undo step", words(p) === w0 && !/[“”]/.test(words(p)) && domText(p) === d0 && v.length === 2 && pic.cue === 0 && box.cue === 0 && box.outAt === 12 && undoN() === n0 + 1 && /^Attach quote/.test(undoLabel()), "box=" + (box && box.cue + "–" + box.outAt));
      await undo(); res("P2c", "scripted pointer", tagPre + "one Undo removes both visuals; narration identical", !q30Vis(p).length && words(p) === w0 && domText(p) === d0); }

    // P3 off-target drop, P4 Escape mid-drag, P5 drag without a selection
    { selectSentence1(); await wait(120); dragStart(tok(p, "keeper", "end")); await wait(150); const pr = C().q30Prose().getBoundingClientRect(); dragMove(pr.left + 60, pr.bottom + 140); await wait(150); const n0 = undoN(); dragDrop(); await wait(350);
      res("P3", "scripted pointer", tagPre + "off-target drop: script unchanged, selection kept, 'Not placed' note shown", words(p) === w0 && domText(p) === d0 && undoN() === n0 && !q30Vis(p).length && /Across the channel/.test(getSelection().toString()) && !!document.querySelector("[data-q30note]")); }
    { selectSentence1(); await wait(120); dragStart(tok(p, "keeper", "end")); await wait(150); const n0 = undoN(); key("Escape"); dragDrop(); await wait(350);
      res("P4", "scripted pointer", tagPre + "Escape mid-drag: script unchanged, selection kept", words(p) === w0 && domText(p) === d0 && undoN() === n0 && /Across the channel/.test(getSelection().toString())); }
    { const k = tok(p, "keeper", "end"); clickCaret(k.x - 12, k.y); await wait(120); dragStart(k); await wait(150); const hadTag = !!document.querySelector("[data-q30tag]"); const n0 = undoN(); dragDrop(); await wait(350);
      res("P5", "scripted pointer", tagPre + "drag with no selection never attaches", !hadTag && undoN() === n0 && words(p) === w0); }

    // P6 Library quote onto the divider below "Across the channel" → new narration row; one Undo; off-target and Escape leave rows unchanged
    { const sample = rowOf(p), L = sample.logical || sample.id, band = [...document.querySelectorAll("[data-occ]")].find(o => o.getAttribute("data-logical") === L), B = band.getBoundingClientRect();
      const snap = () => JSON.stringify((C().state.rows || []).map(r => [r.id, r.words, (r.visuals || []).map(v => v.id + ":" + v.cue + ":" + v.outAt)])), rows0 = snap(), blocks0 = JSON.stringify(C().state.pilotBlocks || []), nRows = C().state.rows.length;
      const ix = C().state.rows.indexOf(sample), next0 = (C().state.rows[ix + 1] || {}).id, chan0 = JSON.stringify(sample.visuals.find(v => /Channel light/i.test(v.title || v.customText || "")) || null);
      getSelection().removeAllRanges(); dragStart({ x: B.left + B.width * 0.3, y: B.bottom }); await wait(250);
      const ln = document.querySelector("[data-stline]"), LR = ln && ln.getBoundingClientRect(), gh = document.querySelector("[data-q30ghost]");
      res("P6a", "scripted pointer", tagPre + "over the divider below “Across the channel”: r29 6 px gold insertion line at the divider, ghost reads “Insert quote as new row”, no caret or range cue", ln && Math.round(LR.height) === 6 && Math.abs(LR.top + 3 - B.bottom) < 2 && gh && /^Insert quote as new row/.test(gh.textContent) && !document.querySelector("[data-q30ov]"), LR ? "line h=" + LR.height + " top=" + Math.round(LR.top) + " divider=" + Math.round(B.bottom) : "no line");
      const n0 = undoN(); dragDrop(); await wait(500); const R2 = C().state.rows, nr = R2[ix + 1], v = (nr && nr.visuals || []).filter(x => /^q30[pb]\d/.test(x.id)), pic = v.find(x => /^q30p/.test(x.id)), box = v.find(x => /^q30b/.test(x.id));
      res("P6b", "scripted pointer", tagPre + "drop creates one narration row at that divider: spoken quote in one pair of curly quotes on the left, picture and quote box on the right covering all 12 words", R2.length === nRows + 1 && nr && nr.words === SP() && !nr.visualOnly && pic && box && pic.cue === 0 && box.cue === 0 && box.outAt === 11 && box.overlay === true && box.customText === Q() && (R2[ix + 2] || {}).id === next0 && undoN() === n0 + 1 && /^Insert quote as new row/.test(undoLabel()) && !document.querySelector("[data-stline]"), nr ? nr.words.slice(0, 20) + " | " + (nr.visuals || []).map(x => x.id + ":" + x.cue + "–" + x.outAt).join(",") + " | next " + ((R2[ix + 2] || {}).id === next0) + " | undo " + (undoN() - n0) + " " + undoLabel() + " | rows +" + (R2.length - nRows) + " | vo " + !!nr.visualOnly + " | line " + !!document.querySelector("[data-stline]") + " | words= " + (nr.words === SP()) + " | ct " + (box && box.customText === Q()) : "no row");
      res("P6c", "scripted pointer", tagPre + "neighbours intact: “Across the channel” narration and Channel light shot unchanged, next row unchanged", words(p) === w0 && JSON.stringify(sample.visuals.find(v => /Channel light/i.test(v.title || v.customText || "")) || null) === chan0 && chan0 !== "null");
      await undo(); res("P6d", "scripted pointer", tagPre + "one Undo removes the whole new row (rows and blocks as before)", snap() === rows0 && JSON.stringify(C().state.pilotBlocks || []) === blocks0);
      const B2 = [...document.querySelectorAll("[data-occ]")].find(o => o.getAttribute("data-logical") === L).getBoundingClientRect();
      dragStart({ x: B2.left + B2.width * 0.3, y: B2.bottom }); await wait(200); const had = !!document.querySelector("[data-stline]"); dragMove(B2.left + B2.width * 0.3, B2.bottom + 200 > innerHeight - 10 ? innerHeight - 10 : B2.bottom + 200); dragMove(10, 10); await wait(150); const n1 = undoN(); dragDrop(); await wait(350);
      res("P6e", "scripted pointer", tagPre + "line shown, then dropped off target: rows unchanged, line cleared", had && snap() === rows0 && undoN() === n1 && !document.querySelector("[data-stline]"));
      dragStart({ x: B2.left + B2.width * 0.3, y: B2.bottom }); await wait(200); const had2 = !!document.querySelector("[data-stline]"); const n2 = undoN(); key("Escape"); dragDrop(); await wait(350);
      res("P6f", "scripted pointer", tagPre + "Escape over the divider cancels: rows unchanged, line cleared", had2 && snap() === rows0 && undoN() === n2 && !document.querySelector("[data-stline]")); }

    // S1–S3 two adjacent quotes from one article: one continuous background, two independent boxes (#123 transparent Graphic rules)
    { const g = tok(p, "gauge.", "end"); dragStart({ x: g.x + 3, y: g.y }, "Q-0031"); await wait(200); dragDrop(); await wait(500);
      const n1 = SP().split(" ").length, endTok = C().q30Toks(p).toks.find(x => x.abs === 13 + n1 - 1), e1 = endTok.rects[endTok.rects.length - 1];
      dragStart({ x: e1.right + 3, y: (e1.top + e1.bottom) / 2 }, "Q-0032"); await wait(200); const tg = (document.querySelector("[data-q30tag]") || {}).textContent || ""; dragDrop(); await wait(500);
      const row = rowOf(p), bgs = row.visuals.filter(v => v.q30bg), bxs = row.visuals.filter(v => /^q30b/.test(v.id)), rb = bgs[0] && C().rangeFor(row, bgs[0]), r1 = bxs[0] && C().rangeFor(row, bxs[0]), r2 = bxs[1] && C().rangeFor(row, bxs[1]);
      const n2 = C().q30Spoken("Crews will check it against the east gauge before the autumn tides.").split(" ").length;
      res("S1", "scripted pointer", tagPre + "Q-0031 then Q-0032 dropped right after it: one article picture spans both quotes; two quote boxes, one per quote", /^Insert quote/.test(tg) && bgs.length === 1 && bxs.length === 2 && rb && rb.start === 13 && rb.end === 13 + n1 + n2 - 1 && r1.start === 13 && r1.end === 13 + n1 - 1 && r2.start === 13 + n1 && r2.end === 13 + n1 + n2 - 1 && words(p).includes("water.” “Crews"), "bg " + (rb && rb.start + "–" + rb.end) + " boxes " + bxs.map(b => { const r = C().rangeFor(row, b); return r.start + "–" + r.end; }).join(","));
      res("S3", "scripted logic", tagPre + "boxes follow #123: overlay Graphic at level 0, own range over the picture, no cutaway return", bxs.every(b => b.overlay === true && !b.level && b.returnAt === undefined && b.kind === "graphic") && bgs[0].kind === "still");
      await undo(); const row2 = rowOf(p), bg2 = row2.visuals.find(v => v.q30bg), rr = bg2 && C().rangeFor(row2, bg2);
      res("S1u", "scripted pointer", tagPre + "one Undo removes the second quote and its box; the picture returns to the first quote’s range", rr && rr.start === 13 && rr.end === 13 + n1 - 1 && row2.visuals.filter(v => /^q30b/.test(v.id)).length === 1 && !words(p).includes("Crews"), rr ? rr.start + "–" + rr.end : "");
      // S2: separate ranges — move the picture's start two words earlier (range edit through the visual's data, not a handle drag)
      const bid = bg2.id, boxId = row2.visuals.find(v => /^q30b/.test(v.id)).id; C().patchSlot("Move picture start", p, bid, { cue: 11 }); await wait(300);
      const row3 = rowOf(p), rp = C().rangeFor(row3, row3.visuals.find(v => v.id === bid)), rx = C().rangeFor(row3, row3.visuals.find(v => v.id === boxId));
      res("S2", "scripted logic", tagPre + "picture and box keep separate ranges: picture can start before the box", rp && rp.start === 11 && rx && rx.start === 13, "pic " + (rp && rp.start) + " box " + (rx && rx.start));
      await undo(); await undo(); res("S1c", "scripted pointer", tagPre + "cleanup: script back to the start", words(p) === w0 && !q30Vis(p).length); }

    // T1–T2 typed quotes: with an attached picture, and without one (Need to Find background), each as a new row
    for (const [id, kindWant, lbl] of [["Q-0033", "still", "typed quote with a picture: background is its attached picture"], ["Q-0034", "needfind", "typed quote with no picture: background is a Need to Find card"]]) {
      const sample = rowOf(p), L = sample.logical || sample.id, B = [...document.querySelectorAll("[data-occ]")].find(o => o.getAttribute("data-logical") === L).getBoundingClientRect(), ix = C().state.rows.indexOf(sample);
      getSelection().removeAllRanges(); dragStart({ x: B.left + B.width * 0.3, y: B.bottom }, id); await wait(250); dragDrop(); await wait(500);
      const nr = C().state.rows[ix + 1], bg = nr && nr.visuals.find(v => v.q30bg), bx = nr && nr.visuals.find(v => /^q30b/.test(v.id)), Qt = id === "Q-0033" ? "Every reading was copied by hand into the harbour log, twice a day." : "We stopped trusting the west gauge years ago.";
      res(id === "Q-0033" ? "T1" : "T2", "scripted pointer", tagPre + lbl, nr && nr.words === "“" + Qt + "”" && bg && bg.kind === kindWant && (kindWant !== "needfind" || bg.customText === "NEED TO FIND") && bx && bx.customText === Qt && bx.qName && bx.qCite, bg ? bg.kind + " · " + (bg.img || bg.customText) : "no row");
      await undo(); }

    // E1–E2 per-use quote-box editor; removing both visuals keeps the words' source attribution
    { const g = tok(p, "gauge.", "end"); clickCaret(g.x + 3, g.y); await wait(150); C().q30SetCur("Q-0031"); clickBtn(document.querySelector('[data-q30place="Q-0031"]')); await wait(300); key("Enter"); await wait(500);
      const row = rowOf(p), bx = row.visuals.find(v => /^q30b/.test(v.id)), bg = row.visuals.find(v => v.q30bg), wIns = words(p);
      const card = document.querySelector('[data-slot="' + bx.id + '"]'); card.click(); await wait(400);
      const ed = document.querySelector('[data-q30ed="' + bx.id + '"]'), ta = ed && ed.querySelector('[data-q30ed-f="text"]'), ct = ed && ed.querySelector('[data-q30ed-f="cite"]');
      const setv = (el, v) => { const pr = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype; Object.getOwnPropertyDescriptor(pr, "value").set.call(el, v); el.dispatchEvent(new Event("input", { bubbles: true })); };
      if (ta) { ta.focus(); setv(ta, "The west gauge is reporting values that don’t match."); await wait(120); ta.blur(); await wait(300); }
      const ed2 = document.querySelector('[data-q30ed="' + bx.id + '"]'), ct2 = ed2 && ed2.querySelector('[data-q30ed-f="cite"]'); if (ct2) { ct2.focus(); setv(ct2, "Harbor Lights Gazette, 3 Sept. 2026."); await wait(120); ct2.blur(); await wait(300); }
      const bx2 = rowOf(p).visuals.find(v => v.id === bx.id), tpl = (document.querySelector("[data-q30ed-tpl]") || {}).textContent || "";
      res("E1", "scripted keyboard", tagPre + "quote-box editor: display text and citation edited on this use; speaker name and title shown; template pinned; narration and saved quote unchanged", !!ed && bx2.customText === "The west gauge is reporting values that don’t match." && bx2.qCite === "Harbor Lights Gazette, 3 Sept. 2026." && ed.querySelector('[data-q30ed-f="name"]').value === "Harbour office" && /EV24 Quote Box · pinned/.test(tpl) && words(p) === wIns && C().q30Spoken(Q()) === SP() && document.querySelector('[data-q30excerpt="Q-0031"]').textContent === Q(), "box=" + bx2.customText.slice(0, 30) + " tpl=" + tpl);
      C().removeSlot(p, bx.id, "Graphic"); await wait(300); C().removeSlot(p, bg.id, "Still Image"); await wait(300); C().q30Scroll(); await wait(500);
      const r4 = rowOf(p), used = (document.querySelector('[data-q30used="Q-0031"]') || {}).textContent || "";
      res("E2", "scripted logic", tagPre + "both visuals deleted: inserted words stay, still attributed to Q-0031 (dotted underline, card still Used once)", words(p) === wIns && !q30Vis(p).length && (r4.qspans || []).some(z => z.qid === "Q-0031") && document.querySelectorAll('[data-q30att="Q-0031"]').length > 0 && /Used once/.test(used), "used=" + used);
      for (let i = 0; i < 5 && words(p) !== w0; i++) await undo(); while (undoN() && /^Edit quote box|^Insert quote|^Delete /.test(undoLabel())) await undo();
      C().setState({ expanded: null }); await wait(200); C().q30Scroll(); await wait(200);
      res("E3", "scripted pointer", tagPre + "cleanup: Undo back to the original narration", words(p) === w0 && !q30Vis(p).length); }

    // W1 obsolete warnings: after a valid attach no “Select words within one row” remains
    { selectSentence1(); await wait(150); dragStart(tok(p, "keeper", "end")); await wait(150); dragDrop(); await wait(600);
      res("W1", "scripted pointer", tagPre + "after a successful attach: no “Select words within one row” or “Not placed” left on screen", !/Select words within one row/.test(document.body.innerText) && !document.querySelector("[data-q30note]") && q30Vis(p).length === 2);
      await undo(); res("W2", "scripted pointer", tagPre + "Undo clears the placement announcement", !liveText() && !q30Vis(p).length); }

    // L1–L5 Library states and thumbnails
    { const lib = (k) => { C().setState({ q30Lib: k }); return wait(350); }, panel = () => document.querySelector("[data-fpanel]");
      await lib("empty"); res("L1", "scripted logic", tagPre + "empty Library: “Nothing in the Library yet”, no cards", !!document.querySelector('[data-q30state="empty"]') && !document.querySelector("[data-q30card]"));
      await lib("denied"); const pt = panel() ? panel().innerText : ""; res("L2", "scripted logic", tagPre + "access denied: message only, no quote text, picture or clip cards", !!document.querySelector('[data-q30state="denied"]') && !document.querySelector("[data-q30card],[data-q30cardpic]") && !/west gauge|Crews will|harbour log/i.test(pt) && !(panel() && panel().querySelector("img,[style*='url(']")), pt.slice(0, 80));
      await lib("media"); const ptx = (document.querySelector('[data-q30pictext="Q-0031"]') || {}).textContent || "";
      res("L3", "scripted logic", tagPre + "media unavailable: banner, quote text kept, picture marked unavailable", !!document.querySelector('[data-q30state="media"]') && /Picture unavailable/.test(ptx) && !!document.querySelector('[data-q30excerpt="Q-0031"]'));
      { const g = tok(p, "gauge.", "end"); clickCaret(g.x + 3, g.y); await wait(150); clickBtn(document.querySelector('[data-q30place="Q-0031"]')); await wait(300); key("Enter"); await wait(500); const bg = rowOf(p).visuals.find(v => v.q30bg);
        res("L3b", "scripted keyboard", tagPre + "placing with media unavailable gives a Need to Find background", bg && bg.kind === "needfind"); await undo(); }
      await lib("normal"); const q = document.querySelector("[data-fp-q]"); const setv = (el, v) => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(el, v); el.dispatchEvent(new Event("input", { bubbles: true })); };
      setv(q, "Tidewater zebra"); await wait(400); const none = document.querySelector("[data-fp-none]");
      res("L4", "scripted keyboard", tagPre + "no search matches: its own message naming the search, with Clear", none && /matches “Tidewater zebra”/.test(none.innerText) && !document.querySelector("[data-q30card]"));
      setv(q, "Duarte"); await wait(400); res("L4b", "scripted keyboard", tagPre + "search matches the speaker (Duarte → Q-0033 only)", [...document.querySelectorAll("[data-q30card]")].map(c => c.getAttribute("data-q30card")).join() === "Q-0033");
      setv(q, "Gazette"); await wait(400); res("L4c", "scripted keyboard", tagPre + "search matches the source title (Gazette → Q-0031, Q-0032)", [...document.querySelectorAll("[data-q30card]")].map(c => c.getAttribute("data-q30card")).join() === "Q-0031,Q-0032");
      setv(q, ""); await wait(300);
      const th = document.querySelector("[data-fp-thumb]"), th0 = th.value; setv(th, "0"); await wait(400); const ex = document.querySelector('[data-q30excerpt="Q-0031"]'), fz = ex ? parseFloat(getComputedStyle(ex).fontSize) : 0;
      res("L5", "scripted pointer", tagPre + "thumbnails at 0%: quote cards text only and legible (≥ 12 px, not clipped)", !document.querySelector("[data-q30cardpic]") && fz >= 12 && ex.scrollHeight <= ex.clientHeight + 1 && ex.getBoundingClientRect().width > 120, "font " + fz);
      setv(th, th0); await wait(300); }

    // L6 placed article-picture thumbnail at normal size
    { const g = tok(p, "gauge.", "end"); clickCaret(g.x + 3, g.y); await wait(150); clickBtn(document.querySelector('[data-q30place="Q-0031"]')); await wait(300); key("Enter"); await wait(600);
      const bg = rowOf(p).visuals.find(v => v.q30bg), el = document.querySelector('[data-slot="' + bg.id + '"]'), th = el && [...el.querySelectorAll("*")].find(x => /scratch_article_capture/.test(getComputedStyle(x).backgroundImage)), r = th && th.getBoundingClientRect();
      res("L6", "scripted logic", tagPre + "placed article picture shows the article capture as its thumbnail, at least 90 × 50 px, top of page in view", !!th && r.width >= 90 && r.height >= 50 && /(top|0%)$/.test(getComputedStyle(th).backgroundPosition) , r ? Math.round(r.width) + "×" + Math.round(r.height) + " " + getComputedStyle(th).backgroundPosition : "no thumb");
      await undo(); }

    // G1–G4 r29 regressions
    { const st = () => JSON.stringify(C().state.rows.map(r => [r.id, r.words, (r.visuals || []).map(v => v.id + ":" + v.cue + ":" + v.outAt + ":" + v.returnAt)]));
      const s0 = st(), sample = rowOf(p), ix = C().state.rows.indexOf(sample), nx = C().state.rows[ix + 1], fk = (C().r13Foot()[0] || {}).key;
      const placed = fk && C().r13PlaceLib(fk, { before: nx ? nx.logical || nx.id : null, start: false }, "regression"); await wait(500);
      res("G1", "scripted logic", tagPre + "footage still places at a divider as a visuals-only row (r29 r13PlaceLib); one Undo restores", C().state.rows.length === JSON.parse(s0).length + 1, "key " + fk);
      await undo(); res("G1u", "scripted logic", tagPre + "footage placement undone, rows identical", st() === s0);
      const chan = rowOf(p).visuals.map(v => v.kind + ":" + v.title).join("|");
      res("G2", "scripted logic", tagPre + "“Across the channel” keeps On Camera, Channel light and the On Camera return", /oc:/.test(chan) && /Channel light/.test(chan) && /OC RESUMES|On Camera resumes/i.test(document.body.innerText), chan.slice(0, 90));
      const sortB = [...document.querySelectorAll("button")].find(b => b.textContent.trim() === "Sort rows"); clickBtn(sortB); await wait(600); const srt = !!C().state.srt; key("Escape"); await wait(300); const back = [...document.querySelectorAll("button")].find(b => /Back to script/.test(b.textContent.trim())); if (C().state.srt && back) clickBtn(back); await wait(500);
      res("G3", "scripted pointer", tagPre + "Sorting opens from Sort rows and closes; rows unchanged", srt && !C().state.srt && st() === s0, "srt=" + srt + " after=" + !!C().state.srt);
      const stB = [...document.querySelectorAll("button")].find(b => /^Show stash/.test(b.textContent.trim())); stB.click(); await wait(600); const stOn = C().state.cmSideView === "stash" || /Stash/.test((document.getElementById("cmt-sidebar") || {}).innerText || "");
      const libB = document.querySelector("[data-foot-btn]"); libB.click(); await wait(600);
      res("G4", "scripted pointer", tagPre + "Stash opens in the sidebar; Show library brings the Library back", stOn && !!document.querySelector("[data-q30card]")); }

    // K1 ⌘⇧F on a highlighted sentence → Attach; Escape → focus and selection back; reopen; Enter commits once
    { const s1 = selectSentence1(); await wait(150); cmdShiftF(); await wait(250); const qs = document.querySelector("[data-q30qs]");
      res("K1a", "scripted keyboard", tagPre + "⌘⇧F on the highlighted sentence opens Attach with focus on the quote", qs && /^Attach quote/.test(qs.innerText) && focusIs("[data-q30opt]") && !document.querySelector("[data-fqs]"));
      key("Escape"); await wait(250);
      res("K1b", "scripted keyboard", tagPre + "Escape closes it and returns focus to the text with the selection", !document.querySelector("[data-q30qs]") && focusIs("[data-prose]") && getSelection().toString() === s1);
      cmdShiftF(); await wait(250); const n0 = undoN(), paras = JSON.stringify(rowOf(p).paras || []); key("Enter"); key("Enter"); await wait(450);
      res("K1c", "scripted keyboard", tagPre + "reopen + Enter (pressed twice) commits exactly once, no paragraph break, popup closed", undoN() === n0 + 1 && q30Vis(p).length === 2 && JSON.stringify(rowOf(p).paras || []) === paras && words(p) === w0 && !document.querySelector("[data-q30qs]"));
      await undo(); res("K1d", "scripted keyboard", tagPre + "Undo clears the placement announcement", !q30Vis(p).length && !liveText()); }

    // K2 valid caret ⌘⇧F → Insert; Escape; reopen; Enter once
    { const g = tok(p, "gauge.", "end"); clickCaret(g.x + 3, g.y); await wait(150); cmdShiftF(); await wait(250); const qs = document.querySelector("[data-q30qs]");
      res("K2a", "scripted keyboard", tagPre + "⌘⇧F at a sentence boundary opens Insert", qs && /^Insert quote/.test(qs.innerText) && focusIs("[data-q30opt]"));
      key("Escape"); await wait(250); const back = focusIs("[data-prose]") && getSelection().isCollapsed;
      cmdShiftF(); await wait(250); const n0 = undoN(); key("Enter"); await wait(450);
      res("K2b", "scripted keyboard", tagPre + "Escape returns the caret; reopen + Enter inserts the 12 words once, wrapped in one pair of curly quotes", back && undoN() === n0 + 1 && words(p).split(" ").length === w0.split(" ").length + 12 && words(p).includes("gauge. " + SP() + " The comparison") && !words(p).includes("““"), words(p).slice(70, 160));
      await undo(); res("K2c", "scripted keyboard", tagPre + "Undo restores the narration", words(p) === w0 && domText(p) === d0); }

    // K3 invalid caret → visible feedback, nothing opens
    { const k = tok(p, "keeper", "end"); clickCaret(k.x - 12, k.y); await wait(150); cmdShiftF(); await wait(250); const note = document.querySelector("[data-q30note]");
      res("K3", "scripted keyboard", tagPre + "⌘⇧F inside a sentence: visible note, no popup, no footage search", note && note.offsetWidth > 0 && !document.querySelector("[data-q30qs]") && !document.querySelector("[data-fqs]"), note ? note.textContent.slice(0, 60) : ""); key("Escape"); }

    // K4 Place in script… by keyboard: visible focus, open, Escape returns focus, reopen, Enter commits once
    { const g = tok(p, "gauge.", "end"); clickCaret(g.x + 3, g.y); await wait(150); const b = document.querySelector("[data-q30place]"); b.focus(); await wait(80); const cs = getComputedStyle(b);
      res("K4a", "scripted keyboard", tagPre + "Place in script… shows a visible focus outline", cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) >= 2, cs.outlineStyle + " " + cs.outlineWidth + " · page has focus: " + document.hasFocus());
      b.click(); await wait(300); // stands in for Enter/Space on the focused button
      res("K4b", "scripted keyboard", tagPre + "activating it opens Insert with focus on Insert quote, dialog clear of the quote card", focusIs("[data-q30go]") && dlgClear());
      key("Escape"); await wait(250); res("K4c", "scripted keyboard", tagPre + "Escape closes and returns focus to Place in script…", !document.querySelector("[data-q30dlg]") && focusIs("[data-q30place]"));
      document.querySelector("[data-q30place]").click(); await wait(300); const n0 = undoN(); key("Enter"); key("Enter"); await wait(450);
      res("K4d", "scripted keyboard", tagPre + "reopen + Enter (pressed twice) commits once, closes the dialog, quote wrapped once", undoN() === n0 + 1 && !document.querySelector("[data-q30dlg]") && words(p).split(" ").length === w0.split(" ").length + 12 && words(p).includes("gauge. " + SP() + " The comparison"));
      await undo(); res("K4e", "scripted keyboard", tagPre + "Undo restores the narration", words(p) === w0 && domText(p) === d0); }
  }
  { const C0 = C(), t = "Every reading was copied by hand, twice a day.";
    res("U1", "scripted logic", "spoken form: one outer pair added, an existing pair not doubled, internal punctuation kept", C0.q30Spoken(t) === "“" + t + "”" && C0.q30Spoken("“" + t + "”") === "“" + t + "”" && C0.q30Spoken(t).includes("hand, twice")); }
  render(out); console.table(out); window.__r30bResults = out; return out;
}
function render(out) {
  let p = document.querySelector("[data-r30b-results]"); if (p) p.remove(); p = document.createElement("div"); p.setAttribute("data-r30b-results", "1");
  Object.assign(p.style, { position: "fixed", right: "8px", bottom: "8px", zIndex: 200, width: "520px", maxHeight: "60vh", overflow: "auto", background: "#ffffff", border: "1px solid #16181c", borderRadius: "8px", padding: "10px 12px", font: "500 11.5px/1.45 ui-monospace,Menlo,monospace", color: "#16181c", boxShadow: "0 12px 30px rgb(0 0 0 / 25%)" });
  const fail = out.filter(r => !r.pass).length; const h = document.createElement("div"); h.style.cssText = "font-weight:700;margin-bottom:6px"; h.textContent = "r30 B r2 scripted checks · " + (out.length - fail) + "/" + out.length + " pass · synthetic events, not a physical mouse or keyboard"; p.appendChild(h);
  out.forEach(r => { const d = document.createElement("div"); d.textContent = (r.pass ? "PASS " : "FAIL ") + r.size + " " + r.id + " [" + r.kind + "] " + r.label + (r.pass ? "" : " · " + r.detail); d.style.color = r.pass ? "#16181c" : "#9b1c1c"; p.appendChild(d); });
  const x = document.createElement("button"); x.textContent = "Close"; x.style.cssText = "margin-top:8px;height:26px;padding:0 10px;border:1px solid #16181c;border-radius:5px;background:#fff;cursor:pointer"; x.onclick = () => p.remove(); p.appendChild(x);
  document.body.appendChild(p);
}
