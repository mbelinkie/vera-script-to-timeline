# Timeline #59 · S03 Integrated Authoring r36 handoff

Packaging only; no design changes. Packaged 2026-11-22. Matthew's conditional wrap-up depends on verifying this exact revision. Final sign-off remains his.

## Contents
- `S03 Integrated Authoring r36 - export.html`: standalone, offline export of the full Timeline r36.
- `S03 r36 Header alignment proposal - export.html`: standalone export of the frozen paired header proposal.
- `source/`: the editable sources, byte-identical to the project files, plus their local support:
  - `S03 Integrated Authoring r36.dc.html`
  - `S03 r36 Header alignment proposal.dc.html`
  - `support.js`: runtime for both sources.
  - `assets/scratch_article_capture.png`: referenced by r36.
  - `r30-checks.js`: referenced by r36's built-in check harness.
- `docs/S03 design decisions.md` and `docs/S03 spec.md`: the decision log and spec as reviewed. The r32–r36 entries are at the end of each file.
- `EVIDENCE.md`: scripted review results at 1280 × 800 and 1024 × 768, plus known limitations and gaps.
- `MANIFEST.md`: byte sizes and SHA-256 for every file.

## How to open
Open either `- export.html` file in a browser. They are self-contained. To edit, open the files in `source/` from that folder, since they load `./support.js`.

## Export note
The proposal export was built from a temporary copy of the frozen proposal with a bundler thumbnail `<template>` added before `</body>`, which the export tool requires. The frozen source in `source/` is unchanged. The r36 source already contained its thumbnail, so it was exported as-is.
