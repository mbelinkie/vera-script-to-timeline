# Manifest · issue-59-r36-handoff

SHA-256 and byte sizes were computed at packaging time, 2026-11-22. Archive root: `issue-59-r36-handoff/`. This file is not listed in its own table.

| Path | Bytes | SHA-256 | Check |
| --- | ---: | --- | --- |
| README.md | 1582 | `1a9aa6766070a0bc739fd8f26f8ee4ea8c558063a622e8c10686ef42dd3cf10b` |  |
| EVIDENCE.md | 5264 | `910b05f7d234cba437a74292afe5f5a586b3a32c49f4ed66576e51e67fe34618` |  |
| S03 Integrated Authoring r36 - export.html | 9716346 | `e671625fd79ca15ffa658e2430061c4e91ea8340acd0c3c164a22dbe1b186564` |  |
| S03 r36 Header alignment proposal - export.html | 433346 | `c0dda1fe10ecca595b6b4332bc02bfe40b3b7b031cacf4b19c2d1f523497fcac` |  |
| source/S03 Integrated Authoring r36.dc.html | 5018552 | `e9325b315e35c285a2c7ca3355572f52f0f7fe01f4bd4c1a9d893ead444c489f` | identical to project file |
| source/S03 r36 Header alignment proposal.dc.html | 22573 | `5493e29c78f39b4949ab8bc171f2120eb213a432a9744510cf035365041a10ac` | identical to project file |
| source/support.js | 69150 | `8fe7df74405f3c55f49b7249c74ea1397e65d07dea2b1bd3b4a489bec2e28cbe` | identical to project file |
| source/assets/scratch_article_capture.png | 92241 | `3a0560b46cfb242a61c22cefa2cc540f68138a641b7930e15be44c132d54636f` | identical to project file |
| source/r30-checks.js | 37554 | `33d6a1e2d90f086fc56cbfd6390327fdb384f3b4d3b86f3803ef783c71b76bc6` | identical to project file |
| docs/S03 design decisions.md | 206022 | `27d55718d6fc664a652663e49f9b427e23409a35de6f498ecff7622ab4d33a65` | identical to project file |
| docs/S03 spec.md | 100853 | `dc9030429cbe9def08476f4bb11e38d40f35a148c184f4c4656bdef72d087f3b` | identical to project file |
