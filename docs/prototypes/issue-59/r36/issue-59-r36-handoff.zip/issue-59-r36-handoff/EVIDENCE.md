# #59 r35/r36 review evidence and known limitations

All results below come from scripted DOM events in the preview: pointer clicks, focus and synthetic key events, plus layout measurements. They are not a manual pass with a physical pointer, a real keyboard Tab order or a screen reader. No r35 or r36 screenshots were captured, because the full-revision preview timed out in the capture tool.

## r36: checks on the exact source revision (2026-11-22)
- **App name:** the VERA app menu names the other app "Research" in both directions. "Research Video Clips" appears 0 times in the r36 source and 0 times in the r36 proposal.
- **1024, long title + Sync failed + presence ("Jonah is editing row 1" / "Jonah edited row 1 · just now"):**
  - Revealing the title shows the full 99-character title, wrapped to 3 lines, below row 1 and inside the frame. The header height doesn't change and Try again isn't covered.
  - The title's accessible name is "Project: [full title]. Switch Script to Timeline project".
  - Revealing presence shows the full string below row 1 without covering Try again, and its accessible name is the full string. Escape dismisses both reveals.
- **1024, default short title:** it truncates (181/121 px) and reveals the same way.
- **1280:** presence isn't truncated, so it isn't focusable (tabindex −1) and shows no reveal.

## Standalone export: checks (2026-11-22)
- The r36 export loads and the harness reads "#59 REVIEW (r36)".
- With the long title, Sync failed and presence, header rows 1 and 2 don't overflow (1250/1250 at 1280, 1002/1002 at 1024), and Try again is inside the frame at both sizes.
- The footer reads "52 picture changes · 0 transitions" and "Est. 21:44 · excludes 1 untimed row", over "3,117 spoken words · 150 wpm manual · 0:58 visual-only".
- 28 + Visual buttons are visible to an Editor. The VERA menu item reads "Research".
- The proposal export renders the frozen r36 proposal text with 0 occurrences of "Research Video Clips".

## r35: checks, unchanged in r36 except the app name and the reveal
- **Header at 1280 and 1024, long title + Sync failed + presence:** rows don't overflow. VERA menu, title, role, sync, Try again, presence, gear, View settings and account are all inside the frame.
- **VERA menu:** focus starts on the other app and ↑/↓ move between items. The three simulated access cases each state their destination, and Escape returns focus to the VERA button.
- **Project menu:** focus starts on the first other project, it explains a same-tab switch, and Escape returns focus to the title.
- **Project settings:**
  - The gear's accessible name is "Project settings" at both sizes. Only Narration pace and Delivery are navigable; the rest is a provisional list.
  - Escape returns focus to the gear, or to the runtime readout if opened from there.
- **+ Visual on the visual-only row k1 (1024):** it opens Footage · On Camera · Still Image, and Escape returns focus to it. All buttons are inside the frame, and a Viewer sees none.

## Not verified
- A manual physical-pointer, keyboard Tab-order and screen-reader pass (VoiceOver/NVDA). This moves to Matthew's stress test in the running app.
- A visual screenshot review of r35 and r36. The background verifier reported no issues, but no images are archived.
- Whether + Visual brightens on keyboard focus in r36. It didn't in the preview because the tab didn't have window focus; it did in r34 via focusin.
- In the standalone export, whether `scratch_article_capture.png` renders. No such image was on screen at load, so it wasn't checked.

## Fixture-only and simulated behavior
- Opening Research in a new tab, Research's access results (1 linked / 2 linked / none authorized), project switching and the account menu are simulated messages only.
- Delivery states (Disconnected / Connected, no folder / Configured), the Build stages, the MP4 path and the Drive upload are simulated.
- Pace samples are fictional timed transcripts. The checkpoint data (revisions 41 and 42 against current 43) is fixture data.
- The "Long title" and viewport buttons in the review strip are review harness controls, not product UI.

## Known prototype defects (not design changes)
- r33 Sorting preview: the app still needs the accepted behavior under #616.
- Expanded connector case: recorded on #59.
- The preview stalls for about 3.5 s while idle in both r32 and r33 and later; the cause is unknown.

## Production gaps
- The suite tooltip primitive for the truncation reveal (#13 §4.3): hoverable, dismissible, persistent, and re-measured on resize.
- A polite status announcement for presence changes.
- Cross-app switching: the minimal navigation envelope (#13 §5.2), each app's membership recheck, chooser and home, and the stored Research ↔ Script to Timeline project link (#13 §5.3).
- Project-level settings storage with role rights. Settings beyond Narration pace and Delivery are provisional.
- Delivery: Drive connection per project and the default folder (#71).
- Resolve render preset listing and capabilities (#329).
- Measuring pace from timed narrator transcripts.
- The #13 contract §4.4 still lists Ideas for Script to Timeline; Ideas was removed in the r32/r33 decisions. The contract needs a note or an amendment.
