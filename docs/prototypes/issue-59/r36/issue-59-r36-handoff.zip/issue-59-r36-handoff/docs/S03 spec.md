# S03 spec: current state

How S03 authoring works now. History and reasoning are in `S03 design decisions.md`; numbers in brackets (D84) point there. Update this file at the end of every notes round.

**Status:** Built (rN) = in the named build · Planned = agreed, on `Implementation backlog.md` · Deferred
**Backend:**
- **Proven**: covered by a merged ticket (#337 create sections and move items; #340 stash, create, place; #341 direction/spoken conversion; #342 returns; #326 music; #119 Wide/Tight)
- **Ticketed**: designed, ticket filed, not delivered (#365–#368, #373)
- **#356**: Show contributions production implementation (backend persistence and change tracking). Requirements are in #62 (S03-CONTRIB-001–008); design and integration are #125.
- **UI**: front end only, no backend work
- **NEW**: invented during design, no ticket yet. Each needs a backend ticket (D107).

Status comes from the decision log. r11 parts 1 and 2 are built (part 2 is `S03 Integrated Authoring r12.dc.html`). The Footage refinements (D125–D134) are built in `S03 Integrated Authoring r13.dc.html`; the Writing integrity pass (D135–D140) is built in `S03 Integrated Authoring r14.dc.html`; the Stash refinements (D141–D142) are built in `S03 Integrated Authoring r15.dc.html`; the Comments, Contributions and workspace pass is built in `S03 Integrated Authoring r16.dc.html`; final verification fixes are in `S03 Integrated Authoring r17.dc.html`; the Chrome-review fixes are in `S03 Integrated Authoring r18.dc.html`, the last complete build; producer follow-up pass 1 is in `S03 Integrated Authoring r19.dc.html`; pass 2 (Footage panel and cards) is in `S03 Integrated Authoring r20.dc.html`; the Timeline #125 passes run through r24–r28; the closeout (D187–D193) is in `S03 Integrated Authoring r29.dc.html`, the current build and the #125 review revision (export in `exports/issue-125-r29/`; awaiting Matthew's sign-off); r13 was partly checked in the UI on 2026-11-13 (see the checklist). Nothing here is production-backed unless the Backend column says Proven.

---

## 1. Layout and top bar
| Rule | Status | Backend |
|---|---|---|
| Top bar order: Aa slider, Sort rows, Show contributions, Show stash, Comments, Options (D78) | Built r8 | UI |
| Options holds one item, Short transcripts (D129); other contents deferred (D79) | Built r13 | **NEW**: per-user preference storage |
| Undo in the top bar, with a recent-actions menu; its label names what Cmd/Ctrl+Z will undo; hidden in Sorting (D34) | Built r16 | UI |
| Top bar fits at both sizes: one row at 1280 × 800; two rows at 1024 × 768 (title, Undo and sliders, then panel buttons and Options) | Built r16 | UI (open question for Matthew) |
| Sentence case for all buttons and labels, "stash" lowercase (D104) | Built r11 (top bar) | UI |
| Thumbnail size slider in the top bar, 0–100%; at 0% only words show and visuals preview on hover or keyboard focus, using the visual's image or its sample thumbnail tile; missing-image visuals don't preview (D102, D110) | Fixed r17 | UI |
| Authoring size 80–150%; text, cards, controls and spacing scale together (D33) | Built | **NEW**: per-user preference storage |
| One sidebar at a time: Footage, Stash or Comments. The active button has a gold outline (D16, D99) | Built r12 | UI |
| Sidebar resizes by dragging the divider: sidebar ≥260px, script ≥560px, double-click resets (D17) | Built | UI |

## 2. Rows
| Rule | Status | Backend |
|---|---|---|
| Two columns: narration left, visuals right | Built | Proven |
| Row ⋯ (Stash, Delete row, Select range) appears on row hover at the top-right, completely inside the row and partly over the first card, and doubles as the drag handle. No reserved strip (D29, D101, D122) | Built r12 | UI |
| No between-row strips. Hovering a divider shows a two-sided **Add row \| Add transition** button; Add row has a ▾ holding Add section. "Comment on gap" is removed (D101, D106) | Built r11 | UI |
| Transitions are allowed at every divider, including before the first row and between sections (D101) | Built r11 | **NEW** if not covered by existing transition work |
| Split and join from a selection. A selection that includes a row's start or end gets Join to previous, Join to next and Split into new row. Join moves only the selected words. Join is disabled across a section break. Split places the new row before or after the original; it's hidden for whole-row selections. Visuals follow their start word; a visual that starts before the selection is clipped at the split; no visual appears in two rows. A stage direction moves only if its start is selected (D97) | Built r11 | **NEW** |
| Select range, then Stash group / Delete group, with keyboard range mode; ranges stay within one section (D42, D60) | Built | Ticketed #366 |
| Screen-reader labels name content, not row numbers; names stay correct after insertion, move and Undo (D61) | Fixed r16 | UI |

## 3. Narration and selection
| Rule | Status | Backend |
|---|---|---|
| Typing in narration, with Make spoken / Make stage direction (D3, D68) | Built r4 | Proven #341 (typing and paste are unproved) |
| Erasing all narration keeps the row and its visuals; word positions and paragraphs are cleared; one Undo restores everything; Delete row stays in the row menu (D135) | Built r14 | **NEW**: empty-narration row with visuals |
| While narration is focused, the status area shows "Return: paragraph · Tab: split row · Esc: leave text" (D136) | Built r14 | UI |
| Escape leaves narration and focuses the row's first visual card (D140) | Built r14 | UI |
| Visuals stay on their intended words after edits, including repeated phrases and non-Latin text; deleted cue words leave the visual without a start word; IME composition is respected (D139) | Built r14 | **NEW**: production text identity for anchors |
| Deleting either bracket of a direction removes its partner (D4, D68) | Built | Proven #341 |
| Return inserts a paragraph break within the row; Tab splits the row at the cursor (empty row at the end, one Undo step), visuals following D97; Esc leaves the text box. A break after the final word moves with a split-off suffix (D114, D137, D138) | Built r14 | **NEW**: paragraph breaks in row text |
| Selections snap to whole words **while dragging**; punctuation goes with the word before it (D95, D105) | Built r12 (live highlight in browsers with CSS highlights) | UI |
| Backspace at a row's start joins it to the row above as a new paragraph; blocked across sections. Straight after a Tab split, it restores any visual the split clipped (D115, D124) | Built r12 | **NEW** (with split/join) |
| Paste: a blank line starts a new row; a single line break is a paragraph break; one Undo reverses only that paste. Rich-text paste (Google Docs) is Deferred (D119, D121, D138) | Built r14 (plain text) | **NEW** |
| Selection menu order: Add visual, Add comment · Split, Join previous, Join next · Stash words; inapplicable items hidden (D120) | Built r11 | UI |
| ⌘⇧F on a selection opens footage quick search (D117) | Built r12 | UI |
| Coverage cue at 0%: a margin line per visual range, Visual Undefined distinct (D118) | Trial r12 | UI |
| Selected words → Add visual opens the type menu, with cutaway and end rules (D94) | Built r10 | **NEW** |
| Selected words → Stash words. Plain words become a note; words with cues become a saved row (D90) | Built r10 | **NEW** |
| Selected words → Add comment | Built | Proven #342 (comment limits) |

## 4. Visuals
| Rule | Status | Backend |
|---|---|---|
| Types: Footage, On Camera, Still Image, Web Capture, Graphic, Onscreen Placeholder, Need to Find, Visual Undefined (D93) | Built | Proven |
| + Visual appears only on rows with no narration; elsewhere, select words (D96) | Built r11 | UI |
| Visual ⋯ menu: Trim (player with in/out handles), Change type, Stash, Comment, Delete, labels only with no helper text. Replaces "comment on this visual" (D100, D123) | Built r12 | **NEW** (Change type, Delete) |
| Deleting a row's last visual leaves a Visual Undefined card (D100) | Built r11 | **NEW** |
| Cards stack in cue order and flash gold when they move (D89) | Built r9 | UI |
| Drag a card to another row: it keeps its trim, lands unattached, and shows Attach to words (D87, D88) | Built r10 | **NEW** |
| Attach to words follows Add visual's rules: the new visual takes the full selection, and neighbouring visuals' ranges shrink or shift around it (D113) | Fixed r11 | **NEW** |
| Stash one visual (not On Camera) (D91) | Built r10 | **NEW** |
| On Camera Wide/Tight toggle | Fixed r11 | Proven #119 (picture transform only) |
| Clip player: movable, resizable, Set in/out, trim handles, transcript click-to-seek (D39) | Built | **NEW**: persisting trims on script footage |
| On Camera fills whatever narration no visual covers and gives way to any visual; Wide/Tight is its only choice, stored per passage (D193) | Principle; prototype audit not done | **NEW**: derive On Camera from uncovered words |
| The first On Camera in each row is a full-size card, even if a still comes first; the compact "OC resumes" card only for a genuine return to the same shot after an intervening cutaway (D190, D193) | Built r29 | **NEW** |
| After range edits and splits: no wordless OC cards; adjacent OC in a row coalesced (D190) | Built r29 | **NEW**: general split/overlap/cutaway validation |
| Dragging a bracket across a whole On Camera passage removes it; other visuals keep at least one word (D192) | Built r29 (known failures below) | **NEW** |
| Range edits: displayed coverage matches the confirmed edit; one Undo restores the full prior sequence | ✗ Fails in r29 (Folded Letter, Amber Lantern, Paper Lanterns); open for implementation | **NEW**: production range-edit issue |
| Timing: at normal speed any three of source in/out and timeline in/out determine the fourth, for visuals and audio; end-anchored audio #574 (D191) | Rule recorded | **NEW** |

## 5. Footage
| Rule | Status | Backend |
|---|---|---|
| Clips are logged Research clips (YouTube). Search matches title and transcript only, everywhere, using the full transcript; logger is a dropdown, dates are Sort (D12, D130) | Built r13 (sample data) | **NEW**: Research clip reference (#340 payload unproved) |
| Quick search ranks transcript matches for the selected words first (D116, trial) | Trial r12 | **NEW**: transcript matching |
| Quick add: search box (title or transcript), unused clips only by default, Show used toggle. Opening it commits nothing; Escape/outside click change nothing; choosing a clip is one Undo step (D98, D131) | Built r13 | **NEW**: search, usage index |
| Footage sidepanel: all project footage, search, logger/label/usage filters, Sort (newest default, oldest, title A–Z; remembered), own thumbnail slider. Clips drag into rows and land unattached (D99, D128) | Built r13 | **NEW** |
| Clicking a clip (panel, Stash, script) opens the player; in the script it plays that use's in/out, in the panel the remembered trim or logged range. Previewing changes nothing (D125) | Built r13 | UI |
| Usage pill "Used once" / "Used N times" goes to the use and flashes it gold; ‹ 1/N › steps through several (D126) | Built r13 | **NEW**: usage index |
| Clip labels: shown, + Label (pick or create), × removes, single-label filter. Labels belong to the source clip and are intended to be Research's set (D127) | Built r13 (fixture, session only) | **NEW**: Research clip-label API; Research naming ("Topics") and colours to confirm |
| Full transcripts by default; Options › Short transcripts shows excerpts with per-clip Show full transcript / Show less (D129) | Built r13 | **NEW**: per-user preference |
| Place in script… from the panel, using the Stash gap chooser; makes a Footage row (D132) | Built r13 | **NEW** |
| Research: none logged empties the panel and quick search with Open in VERA Research (D133) | Built r13 | UI |
| A clip remembers its latest manual trim, even after that instance is changed or deleted. New placements use it; existing instances keep their own trims (D99) | Built r12 (this session only) | **NEW**: clip-level trim |
| Unavailable clips can be placed; the card shows the reason and offers Replace clip… and Open in VERA Research (D15) | Fixed r17 | Proven (placement); **NEW** (Research reconnect) |
| Open in VERA Research when a clip isn't logged yet (D13) | Built | Research owner |
| Brief transition between sidebar panels | Build note only | UI (production) |

## 6. Sections (script)
| Rule | Status | Backend |
|---|---|---|
| Sections are organizational markers exported to Resolve; breaks go only between rows (D106) | Built r11 | **NEW**: Resolve marker export |
| Add section from the divider's ▾ opens an inline title field (D106) | Built r11 | **NEW** |
| Section header ⋯: Rename, Delete break. Deleting merges into the previous section (D106) | Built r11 | **NEW** |

## 7. Stash
| Rule | Status | Backend |
|---|---|---|
| Notes, clips, saved rows and groups in user sections. Add note, Add section, Add clip at the top (D9, D35, D57) | Built | Proven #337, #340 |
| Count covers every entry; the header breaks it down by kind; group rows count, the group itself doesn't (D1, D45) | Built | UI |
| Notes are plain text with literal brackets (D56) | Built | Ticketed #365 |
| Notes are checklist items, with Hide completed (D62, D63) | Built r5 | Ticketed #373 |
| Placing a note copies it as **spoken** text and checks the original (D64, D84) | Built r8 | Ticketed #373 (spoken vs direction is **NEW**) |
| Per-insertion return of untouched copies (D66) | Built r5 | Ticketed #373 |
| Attached footage: one clip per note, shown as a strip, with Replace and Detach (D49–D53) | Built | Ticketed #367 |
| Include items below (D58, D65) | Built | UI over #340 |
| Drag into the script between rows, or into a row: a gold text cursor for notes, a gold line on the visuals side for clips (D18, D86) | Built r10 | Proven (between rows); **NEW** (into a row) |
| A note dropped into a paragraph inserts spoken words (literal brackets), checks the note, copies attached footage to the first inserted word, has no return link; nested items stay put; one Undo/redo (D141, D142) | Built r15 | **NEW** |
| Stash clips sit in their level's checkbox lane | Built r15 | UI |
| Place in script: destination filter; preview and toast say spoken text and what's copied vs moved; row action reads Return to stash | Built r15 | UI |
| Stash player for an unavailable source shows the reason and logged range, with no Play | Built r15 | UI (reconnect deferred) |
| The drag ghost trails the pointer from its top-left corner (about 12px offset) so the gold cursor and line stay visible (D85, D112) | Built r11 | UI |
| Drag out of the script into Stash; drag within Stash to reorder and nest (D19, D20, D82) | Built | Proven #337, #340 |
| Saved rows and groups open in the script's row renderer, ask to save on close, and groups can add or remove rows (D41, D47, D48, D59) | Built | Ticketed #366 |
| Returns go to their original place, otherwise the top of Stash unsectioned; mixed returns allowed (D40, D54, D55) | Built | Ticketed #368 |
| One-click delete with Undo (D26) | Built | Proven |
| Attribution @name · date, hidden on your own items (D32) | Built | **NEW** if not in #340 |
| Stash text size slider 80–200% (D33, D46) | Built | **NEW**: per-user preference |
| Rename Stash sections; deleting one moves its items to unsorted at the top (D109) | Built r12 | **NEW** |
| Reconnect missing footage from Stash | Deferred | — |

## 8. Comments
| Rule | Status | Backend |
|---|---|---|
| Comments sidebar; yellow words open a discussion; orphaned comments collapse | Built | Proven #342 |
| Comments show in Sorting. Clicking one expands its row and scrolls to it; clicking another collapses the first (D103) | Built r12 | UI |
| Comment-only access to a document | Deferred | — |

## 9. Sorting
| Rule | Status | Backend |
|---|---|---|
| Sort rows opens Sorting; ← Back to script is gold (D80) | Built | UI |
| Accept/Discard; organization vs edits classification (D67) | Built r4 | Proven #342 |
| Show contributions hides in Sorting; Stash stays available (D77) | Built | UI |

## 10. Show contributions (option B, D108; requirements #62, design #125, production #356)
| Rule | Status | Backend |
|---|---|---|
| Bar: See contributions, first-name chips, ✕ top-right, timeframe count pill, gold Mark all reviewed (D69–D74). Mark all reviewed acknowledges every pending change by others up to the frozen boundary, whatever chip or Show removed setting; later arrivals stay pending; a failed save marks nothing; Sorting Accept/Discard acknowledges nothing (verified r16; scope question open for Matthew) | Built r8 | #356 |
| Removed rows use the Reconciliation format; Show removed default follows the range (D75, D76) | Built r8 | #356 |
| Overwritten-change catch-up line (D71) | Built r8 | #356 |

## 12. Research #75: every source kind (r6, R6-1 to R6-8)
| Rule | Status | Backend |
|---|---|---|
| Sources lists YouTube, web pages, audio, images, typed-quote sources and video files, with a Kind column (R6-4) | Built r6 | **NEW** |
| Web page opens in Workspace: text left, logging tools right; sentence selection, Shift-click extends (R6-2) | Built r6 | **NEW** |
| Save still from a page picture; quotes logged with their citation (R6-2) | Built r6 | **NEW** |
| Auto-filled values italic grey until edited or confirmed with Enter (R6-3) | Built r6 | **NEW** |
| Typed quote side drawer (R6-5) | Built r6 | **NEW** |
| Clips renamed Library, Kind filter (R6-6) | Built r6 | **NEW** |
| Web: file-dependent actions disabled with a reason (R6-7) | Built r6, under review | **NEW** |
| Browser extension, 8 states (R6-8) | Drawn r6 (static) | **NEW** |
| Audio and image Workspaces | Not drawn | — |

## 11. Deferred
Rich-text paste from Google Docs (D121) · spell check · word count and estimated length · comment-only access · Options contents · reconnecting footage from Stash · music beyond #326 · motion and framing.

---

## Pending producer choices (Matthew)
- **Sign off the #125 handoff** on r29 (review revision, source and export in `exports/issue-125-r29/`), with the range-edit failures open for implementation.
- Mark all reviewed scope: stay global, or only what's shown for the selected person / with removed items hidden?
- Who may Resolve, Reopen and Reattach comments?
- Adopt the 0% coverage cue trial (D118)?
- Two-row top bar at 1024 × 768, or shorter labels?
- Research r6: Panel A or B for all source kinds? Which actions are limited on Web (R6-7)? Is "Library" the right name?
- Research Library detail (R7-1 to R7-3): decided 2026-11-19. Test: from midway down a filtered Library, open a clip and then Open source. The transcript scrolls to the saved range. Back returns to the same item with focus on Open source. Close detail (1280) or Back to Library (1024) restores the list's scroll position and row focus.

## Unscoped functionality (needs backend tickets)
Every **NEW** item above, grouped as possible tickets:
1. **Row restructuring:** split and join from a selection, with visual carry rules (§2).
2. **Script sections:** create, rename and delete, with Resolve marker export (§6).
3. **Visual lifecycle:** delete, change type, move between rows with unattached state and Attach to words, stash one visual, add on a selection with cutaway rules (§3, §4).
4. **Word-level Stash operations:** stash selected words; drop a note into an existing row (§3, §7).
5. **Footage library:** Research clip reference, title/transcript search, usage index, clip-level remembered trim, trim persistence on script footage, shared clip labels read and written through Research, per-user Sort and Short transcripts preferences (§4, §5).
6. **Stash sections:** rename and delete to unsorted (§7).
7. **Notes as spoken text** on placement (D84), versus #373's direction behavior (§7).
8. **Per-user view preferences:** Authoring size, Stash size, Thumbnail size (§1, §7).
9. **Paragraph breaks and paste** (D114, D119, D138): paragraph storage, prompter and export; paste parsing into rows (§3). Prototype behaviour only; real persistence, prompter output and Resolve export are integration requirements (R16).
13. **Picture-sequence validation and timing** (D190–D191): split, overlap and cutaway validation in one edit; the three-of-four timing rule for visuals and audio; end-anchored audio (#574). Estimated-endpoint visuals wait for the Footage design story.
14. **Range edits** (D190, D192, D193; one production issue, open for implementation): after a bracket drag, keyboard bracket move or confirmed Reselect, the displayed brackets, cards and On Camera passages match the confirmed edit; a neighbour's start moves only where its words are now covered; one Undo restores every range, On Camera passage and framing, and card order. Known r29 failures are in the test checklist.
12. **Empty narration rows and anchor identity** (D135, D139): storing a row with visuals and no words; a production text-identity model for visual anchors (the prototype uses edit-position mapping).
10. **Transitions at every divider**, if not already covered (§2).
15. **Research source kinds** (R6): web-page text extraction and citation lookup, stills, audio transcripts, typed quotes, local-file relink, browser extension endpoints and sign-in.
11. **Attribution on Stash items**, if #340 doesn't store author and date (§7).

---

## Test checklist
Run against each build. ☐ = untested.

**Research r6 (every source kind)**
- ☐ Sources shows a Kind column; web page, audio, image, typed and missing-file rows render at 1280 and 1024
- ☐ Opening the web page shows text left, tools right, in Panel A and Panel B
- ☐ Click selects a sentence, Shift-click extends; A's Start/End nudges work
- ☐ Editing an auto-filled detail (or Enter) turns it from italic grey to normal
- ☐ Log quote adds Q-00xx to Already logged here and to Library; Save still adds S-00xx
- ☐ Typed quote drawer logs to Library; Log quote disabled while the quote is empty
- ☐ Library Kind filter shows only that kind; Label filter and search still apply
- ☐ Web: "From this Mac…" disabled with Desktop only; missing file offers Open in Desktop to relink
- ☐ Browser extension flow shows all 8 states

**Top bar and view**
- ☐ The top bar reads, in order: Aa, Thumbnails, Sort rows, Show contributions, Show footage, Show stash, Comments, Options; all labels in sentence case
- ☐ Thumbnail size at 0% hides every card's image; hovering any visual shows its preview, reliably, in every row
- ☐ Thumbnail size at 100% and 50% scales cards; the value persists after reload
- ☐ Authoring size scales text, cards and controls together
- ☐ Only one sidebar opens at a time; the active button has a gold outline
- ☐ The sidebar divider respects 260px and 560px minimums; double-click resets it

**Rows**
- ☐ No space is reserved between rows; hovering a divider shows Add row | Add transition on the line
- ☐ Add row's ▾ offers Add section
- ☐ Add transition works before the first row, between rows, and between sections
- ☐ Row ⋯ appears only on hover, at the top-right, completely inside the row and over the first card; the first card sits near the top of the column
- ☐ Row ⋯ dragged into Stash stashes the row
- ☐ Select range: the pointer and ↑/↓/Enter/Esc both work; a range can't cross sections

**Split and join**
- ☐ A selection including the row start offers Join to previous and Split; one including the end offers Join to next and Split
- ☐ A whole-row selection offers both joins, no Split; a mid-row selection offers none
- ☐ Join is disabled when the neighbouring row is in another section
- ☐ A visual whose start word is selected moves with the selection and its end is clipped
- ☐ A visual that starts before the selection stays and ends at the split
- ☐ No visual appears in both rows
- ☐ A stage direction moves only when its start is selected
- ☐ Split places the new row before (start selected) or after (end selected) the original
- ☐ Undo reverses each of these exactly

**Narration**
- ☐ Selection grows a whole word at a time while dragging, never by letter
- ☐ Punctuation is selected with the word before it; range brackets are skipped
- ☐ Make spoken / Make stage direction follow the selection; deleting one bracket removes its pair
- ☐ Return adds a paragraph break inside the row; Backspace at the start of a paragraph removes it; Return at a row's start explains Tab instead
- ☐ Paragraphs survive Undo, split, join, Stash and Sorting (export not in the prototype)
- ☐ Tab mid-row splits at the cursor; visuals after the cursor move, one spanning it is clipped; Undo restores
- ☐ Tab at the end of a row adds an empty row; Esc leaves the text box
- ☐ Backspace at a row's start joins it above as a new paragraph; blocked at a section break; Undo restores
- ☐ Tab mid-visual, then Backspace straight away: the clipped visual gets its original range back
- ☐ Pasting text with blank lines makes one row per block; single line breaks stay as paragraphs; one Undo reverses the paste
- ☐ Pasting into a Stash saved-row editor keeps everything in that row (blank lines become paragraphs)
- ☐ The selection menu shows groups in order, hiding items that don't apply
- ☐ ⌘⇧F on a selection opens footage quick search
- ☐ At 0% thumbnails, the coverage cue shows every visual range and makes Visual Undefined stand out
- ☐ Add visual on a selection: the type menu opens; the start, end and cutaway rules match D94

**Visuals**
- ☐ + Visual appears only on rows with empty narration
- ☐ Visual ⋯ offers Trim, Change type, Stash, Comment, Delete, with no helper text; no separate comment button
- ☐ Trim opens the player with in/out handles; the trim saves
- ☐ Change type works between every pair of types
- ☐ Deleting the last visual leaves Visual Undefined
- ☐ On Camera Wide/Tight changes the framing
- ☐ No stray mini On Camera card appears (regression: the "But when he competed in Melodifestivalen this year," row)
- ☐ Dragging a card to another row keeps its trim and lands unattached; Attach to words then works; Esc cancels
- ☐ Attaching to a span that crosses two visuals: the new visual gets the full span, the earlier visual ends where it begins, and the later one starts after it
- ☐ Cards reorder by cue with a gold flash

**Footage**
r13 UI results (2026-11-13 and 2026-11-14, run in the prototype at 1280 × 800): ✓ passed · ✗ failed · ☐ not checked
- ✓ Unused clip (panel body) and used clip (panel title) open the player; panel preview plays the remembered trim, else the logged range
- ✓ Three uses of one clip (harness "Footage: 3 uses") keep distinct trims in the script (1.0–4.0, 3.0–7.5, 5.0–9.0)
- ✓ Usage pill and ‹ › go to and flash the correct visual; position text updates; the panel stays open
- ✓ Labels: pick existing, create new (appears in the label filter), remove; × does not open the preview; Escape in + Label closes it and returns focus to + Label
- ✓ Regression: select all of "The harbor light is green.", Add visual › Footage, Escape: no new visual, On Camera unchanged. Choosing a clip then one Undo restores the row
- ✓ Sort: newest (harbor, sensor, k2, ferry, blink, k1, fog, horizon, gulls), oldest and Title A–Z orders correct, including same-date tie-breaks
- ✓ Filters combine: label Channel light → 2 clips; + logger Wren → 2; + sort Title → same 2 in title order; + Used → none, with "No clips match" and Clear search and filters (clears filters, keeps the sort)
- ✓ Metadata-only queries "Dana", "Aug" and "2026" match nothing; "umbrellas" (late in a transcript) finds Harbor caretaker
- ✓ Full transcripts by default. Options › Short transcripts: unchecked by default; checking it shows excerpts and stores the preference in this browser. Show full transcript on one clip shows all 249 characters, other clips stay short; Show less collapses only it; the checkbox stays checked; with a search, the excerpt is centred on the match
- ✓ Usage radio group: one tab stop; ArrowRight, End and Home select and move focus
- ✓ Enter on a nested ⋯ inside a Footage card is not taken by the card; Enter on the card opens the player with focus inside; Escape closes it and focus returns to the card. Panel title preview → Escape returns focus to the title
- ✓ Place in script…: the gap chooser opens with 29 destinations; Escape cancels and focus returns to Place in script…; placing adds one Footage row (pill shows Used once, panel search and sort kept); one Undo removes it
- ✓ Research: none logged: the panel shows the empty state with Open in VERA Research, the top-bar count reads 0, and quick search says no clips are logged and offers Open in VERA Research
- ✓ Stash clip click opens the player (including the unavailable Night ferry clip, which shows its reason in the Stash item)
- ☐ Unavailable Footage card in the script (expand-for-recovery on click): test placement timed out
- ☐ Remembered Short transcripts after a page reload (storage write confirmed; reload not performed)
- ☐ 0% thumbnails with a real pointer: only synthetic mouseover events were possible here, so this isn't counted as a pass; keyboard focus preview not separated from it
- ☐ 1024 × 768 layout of the panel and Options: the screenshots timed out
r14 Writing results (2026-11-14, run in the prototype; synthetic keyboard, paste and edit events in a real browser page): ✓ passed · ✗ failed · ☐ not checked
- ✓ Clearing all narration in a row with three visuals: row and visuals stay (ordinals removed), the cell is empty, the hint disappears on blur; Sorting and back: still empty; one Undo restores the words and both visual ranges
- ☐ Row menu Delete row checked separately in r14 (not run)
- ✓ The hint appears only while narration is focused; Escape removes it and puts focus on the row's first visual card
- ✓ Tab at the end of a row: one new row, focus in it; one Undo removes it, redo re-adds it, Undo again removes it
- ✓ Add row above the first row and Add row from a row divider: one row each, one Undo each
- ✓ Paragraph breaks mid-row and after the final word; Tab split of the suffix moves the terminal break into the new row; immediate Backspace restores the original row (3 breaks); after an edit, Backspace joins normally (adds the join break, keeps the terminal break); Undo steps back through join, edit and split exactly
- ✓ Paste "a\nb\n\nc" at a row end: one paragraph break, one new row; one Undo returns the row to exactly its prior text
- ✓ After an earlier narration edit, pasting identical words with a blank line splits the row; one Undo removes only the paste, the earlier edit stays
- ✗→✓ A paste sometimes didn't create its row on the slow page (timing race), seen twice; fixed in r14 and passed after reload
- ✓ Repeated cue phrase: inserting a copy before both, then text between them, keeps the visual on the second occurrence (positions 112 → 117 → 122 → 128)
- ✓ Non-Latin: replacing the anchor words with 東京 大阪 京都 keeps the visual on them; inserting 札幌 before 東京 moves the cue to 東京; deleting the anchor words leaves the visual without a range rather than jumping to an earlier copy; Undo restores position 112
- ☐ Real IME composition (only the code guard exists; no IME was available to test)
- ✓ Tab through a spanning visual (⟦1 clipped), then switching Stash/Footage/Comments and 1280→1024, then Backspace: exact original text and both ranges restored, viewport stays 1024
- ✓ Backspace at the start of a section's first row is refused ("Rows don’t join across a section break.")
- ✓ Card keyboard: r13 nested-control fix kept (not retested in r14)
- ✓ Footage smoke check in r14: 9 clips, labels shown, Used once pill flashes the right visual, title opens the player; Short transcripts and the Title sort were still applied after a page reload
Residual Footage checks: ✓ Short transcripts across reload (passed in r14) · ☐ unavailable Footage card in the script · ☐ 0% thumbnails with a real pointer, keyboard focus preview separately · ☐ 1024 × 768 layout of the Footage panel and Options (screenshots time out on this page)
r15 Stash results (2026-11-14, run in the prototype with synthetic pointer, keyboard and edit events): ✓ passed · ✗ failed · ☐ not checked
- ✓ Unchecked note dropped into a paragraph by pointer drag: gold vertical text cursor shown during the drag, spoken words inserted at the cursor, note checked and still in Stash, no Return button on the row; Undo removes the words and unchecks; redo reapplies; deleting the inserted words later leaves the note checked
- ✓ Completed note with footage and brackets dropped mid-paragraph: brackets stay plain text (not direction styling), a Footage visual starts on the first inserted word, the note keeps its footage strip, nested notes/clip keep their levels and checkboxes; one Undo removes words and footage and keeps the note's prior (checked) state
- ✓ Include items below with completed child and unfinished grandchild: preview "Places 3 rows (spoken text + footage, then the items below). Notes are copied … 1 clip or saved row moves out of Stash." Placing skips the completed child, copies root and grandchild, moves the clip; one Undo restores; a completed root places the same way
- ✓ Return to stash on untouched copies: a manually checked root stays checked; a grandchild checked by the insertion unchecks; no duplicate saved rows; manual uncheck/recheck after a placement keeps it checked on return
- ✓ An edited copy has no Return to stash; row ⋯ › Stash says "Saves this row in Stash (its link to the note ended)" and creates a saved row while the note stays checked
- ✓ Root and nested clips align with their level's checkbox lane (x within 1px)
- ✓ Destination filter: "harbor" narrows to matching rows and keeps a valid selection; no match shows "No destinations match" with Place disabled; Escape cancels and focus returns to the item's ⋯ (focusin observed)
- ✓ Deleting a Stash section moves its items, in order and nesting, to the top; one Undo restores
- ✓ Unavailable Stash clip: reason, logged range and placeability shown, no Play; an available clip still plays
- ✓ Smoke: narration hint, Footage panel, panel preview
- ☐ Group editor Save/Cancel, close confirmation and one/zero-member cases (code unchanged; no group in the current sample)
- ☐ Completed-note gold drag feedback with a real pointer (only synthetic events)
- ☐ IME, screenshots and real-pointer checks remain unavailable in this environment
r16 results (2026-11-14, run in the prototype with synthetic events): ✓ passed · ✗ failed · ☐ not checked
- ✓ Sorting: opening a comment expands its own row (aria-expanded) and scrolls it near the top; opening another collapses the first
- ✓ Replacing a commented shot (Change type › Still Image): the comment moves to Orphaned with "Shot replaced" and saved context naming the original clip; one Undo reattaches it
- ✓ Mark all reviewed with Dana selected and Show removed off: all 6 pending changes acknowledged; simulated failure: "Couldn’t save your review. Nothing was marked reviewed." with 6 still pending; with the boundary frozen, a later arrival stays pending (7 → 1) with "Anything later stays pending"
- ✓ Sorting Accept and Discard all both leave 6 pending
- ✓ D71: with Jonah selected, "Your later edit replaced 1 unreviewed change by Jonah Reyes in …"; chip shows 3; after Mark all reviewed, chips and line are gone
- ✓ Top bar: 1280 × 800 one row, title not clipped; 1024 × 768 two rows, title full width, Options and panel buttons on row 2, nothing overlapping
- ✓ Persistent Undo: "Nothing to undo in this session" at start (disabled); after an edit "Undo Edit narration (Cmd/Ctrl+Z)"; the ▾ menu lists it first above earlier-session entries; clicking Undo reverts exactly and the label returns to nothing
- ✗→✓ Card accessible names after Add row named the row above (seen before the fix, and already off by one for later rows); after the fix every card name matches its row after insertion, Undo, stashing a row and placing it elsewhere
- ✓ Compact fixture: Contributions bar, toast and player don't overlap at 1024 × 768
- ☐ Comment Resolve/Reopen/Reattach permissions (product question)
- ☐ Real-pointer checks (0% hover, drag feedback), IME composition and screenshots remain unavailable here
r17 results (2026-11-14): method in brackets. ✓ passed · ✗ failed · ☐ not checked
- ✗→✓ 0% keyboard focus on "Harbor caretaker" (Footage) and two Still Images ("Ticket window…", "Recipe card"): no preview in r16 (no image of their own); in r17 each shows its thumbnail tile, and blur and Escape dismiss it [programmatic focus/blur; first run was after moving the slider to 0%]
- ✗→✓ Fresh load with 0% saved: before the fix nothing previewed until the slider was moved (found by review); after the fix, mouseover on Harbor caretaker opens the preview and mouseout closes it [reload with saved 0%; synthetic mouseover/mouseout]
- ✗→✓ Focus on an offscreen card (Tab scrolls it into view): the preview flashed for under 100 ms then closed (found by review); after the fix it stays open for the whole 1 s sample on both the Recipe card and Harbor caretaker, sits beside the scrolled card, and blur closes it; a hover preview still closes on scroll [programmatic focus() from the top of the script, sampled every 100 ms]
- ✗→✓ Card-to-card focus (fast Tab): the new card's preview closed about 160 ms later (found by review); after the fix it stays open for the full 0.8 s sample, both between two visible Still Images in one row and from Harbor caretaker to an offscreen Still Image; moving focus off the cards (to Undo) closes it [programmatic focus() sequences, sampled every 100 ms]
- ☐ On Camera at 0% doesn't preview (existing behaviour: its thumbnail is the presenter frame)
- ☐ Missing-image visual at 0% (no "Image file needed" visual in the current sample)
- ✓ Row ⋯ › Delete row: confirmation, deletion, one Undo restores it in place with identical text [UI clicks]
- ✗→✓ Unavailable clip placed from Stash: r16 showed the reason but no recovery; r17 shows Replace clip… and Open in VERA Research; Replace clip… → choosing a clip clears the warning; one Undo restores the unavailable clip [UI clicks]
- ✓ Two-row range → Stash group; Place group back (2 ordinary rows, all 6 visuals kept); one Undo returns the group; another Undo restores the rows in place [UI clicks + keyboard range]
- ☐ Group with nested notes or attached footage (none in the sample)
- ☐ Real pointer hover and native drag feedback, IME composition, screenshots (not available in this environment)
Independent Chrome review of r17 (Matthew, native keyboard and pointer): ✓ passed
- ✓ With 0% saved, native Tab and real pointer movement show the thumbnail on the Recipe card (Still Image) and Harbor caretaker (Footage); Tab away or moving past the card dismisses it
- ✓ Row ⋯ › Delete row, then one toolbar Undo, restores the short row and its On Camera visual
- ✓ Night ferry clip placed from Stash shows its recovery choices; Undo returns it to Stash
- ✓ Cold open group, Include items below: two unfinished notes copied, completed note skipped, Gulls over the pier moved, horn attachment kept; one Undo restores hierarchy, attachment and completion marks
- ✗ (fixed r18) After the delete and toolbar Undo, the delete toast still offered Undo
- ✗ (fixed r18) The placed Night ferry card's accessible name ended "Image file needed on this computer"
r18 results (2026-11-14, prototype; UI clicks and keyboard events):
- ✓ An older narration edit, then Delete row on "The harbor light is green", then toolbar Undo: row and On Camera back; toast reads "Undid Delete “The harbor light is green”." with no Undo; the toolbar now offers "Undo Edit narration", and the older edit is still in the text
- ✓ Same sequence with Cmd/Ctrl+Z: same result
- ✓ Same sequence with the toast's own Undo: one copy of the row restored, "Restored … with its discussions attached as before.", toolbar still offers "Undo Edit narration"
- ✓ Night ferry placed from Stash: accessible name ends "Source unavailable · the video was removed from this project’s media"; Replace clip… and Open in VERA Research still shown
- ☐ Genuine IME composition and native drag feedback (hands-on check still pending)
r19 pass 1 results (2026-11-14, prototype; scripted clicks, value changes and synthetic pointer drags — not native input): ✓ passed · ✗ failed · ☐ not checked
- ✓ Audio: row ⋯ on a narration row shows Add audio bed starting in this row; the picker opens on the row; Escape closes it with no bed, no Undo entry, focus on row ⋯
- ✓ Audio: picking Harbor Tide Bed adds M3 with its panel; Source trim 0 → 0.5 then Fade out 2 → 2.5; toolbar label read "Undo Change source trim of M3", then "Undo Change fade of M3"; three Undos: fade back to 2.0, trim back to 0.0, then M3 removed, label "Nothing to undo in this session"
- ✓ Quiet piano in Sorting: start and end marks on s16/s18; details show its start and end rows
- ✓ Reselect range: shown on footage card hover and in the visual ⋯ menu; selecting words opens a confirm; Escape keeps the brackets unchanged with no Undo entry and focus back on the card
- ✓ Partial overlap ("generous … traveler" across visuals 1 and 2): Set range made room under D113 (visual 1 resumes after); one Undo restored ⟦1 1⟧ ⟦2 2⟧ ⟦3 3⟧
- ✓ Exact match (visual 2 → visual 3's words): Swap ranges offered and focused; after the swap the cards read 1 Still, 2 Still, 3 Footage (cue order); footage trim note unchanged ("8.0s of footage remains"); one Undo restored order and brackets
- ✓ Visuals-only row: a stashed Still dropped into Harbor caretaker arrives with no Attach to words and Hold 4.0 s; dragging it below the Footage reorders (one Undo); Hold 6 committed with Enter; −2 refused ("Kept 6.0 s")
- ✓ Match audio duration: offered only once a bed spans the row (fixture); checking it follows M3 (132.0 s, read-only); with two cues a chooser appears and M4 can be picked; removing M4 falls back to 6.0 s with a note; Undo restores the match
- ✓ Undo to the start restores s01's three visuals, brackets and Harbor caretaker's single Footage card
- ✓ Row ⋯ and first visual ⋯: row ⋯ at least 12 px above the first card at 1280 × 800 and 10 px at 1024 × 768; each hit test lands on its own button
- ✓ No coverage-cue lines render at 0% thumbnails
- ☐ Footage trim after a move between two visuals-only rows (existing D87–88 behaviour, not re-checked in r19)
- ✗→✓ Toolbar Undo label after audio Undo (reported stale by review). After the fix, one step per check: add → "Undo Add audio bed M3…"; trim 1 → "Undo Change source trim of M3"; fade 2.5 → "Undo Change fade of M3"; Undo → "Undo Change source trim of M3" (1 bed); Undo → "Undo Add audio bed M3…" (1 bed); Undo → "Nothing to undo in this session" (0 beds)
- ☐ Slider Undo label with real ArrowRight keys (hands-on)
- ☐ Native pointer drag feel, IME composition
Codex observations of r19: ✓ keyboard trim/fade with correct Undo labels; ✓ separate row/visual ⋯ targets at 1024 × 768.
r20 pass 2 results (2026-11-14, prototype; scripted clicks, keyboard events and simulated pointer events — not native pointer):
- ✓ Script Footage card click plays that use's trim and shows a Trim button; Trim opens the controls (aria-expanded true, label Hide trim)
- ✓ Three uses of Harbor mouth play 1.0–4.0, 3.0–7.5 and 5.0–9.0 s; the panel preview opens paused with trim open on the remembered 5.0–9.0; Clear out in the panel → a later placement plays 5.0–10.0 while the three uses keep their trims
- ✓ Short transcripts checkbox under the panel search, checked from the stored preference; Options control gone
- ✓ Timed clip at logged bounds: opening excerpt. Trimmed 15.0–20.0 s: "…The old schedule is still pinned behind the glass. I copy the routes by hand on a clean sheet,…" with note; updated live while the in point moved (7.4 s showed later speech); Show full transcript/Show less toggles one clip, checkbox stays on; 9.0–13.0 s: "No speech between 9.0 and 13.0 s." with Show full transcript
- ✓ Harbor mouth trimmed (no timings): full transcript with "A trimmed excerpt isn’t available…" note
- ✓ Clicking the label Tide filters the panel to Harbor mouth, no player, focus on the label control; Any label clears it (10 clips)
- ✓ Place in script: a pointerdown outside closes it with no placement or Undo entry; inside keeps it; Escape closes
- ✓ Rename Harbor caretaker's placement to "Caretaker at the window": card shows the name and "Source: Harbor caretaker"; card and comment-marker names use it; one Undo entry; Escape cancels; Undo restores; offered for Still Image, not On Camera
- ✓ 0% hover/focus previews as listed in the decisions build notes (simulated events)
- ☐ Native pointer hover at 0% (Codex)
- ☐ Production transcript timing availability/granularity
Codex observations of r20 (Chrome): ✓ panel click opens the player with trim open; ✓ Short transcripts checkbox in the panel; ✓ native pointer hover at saved 0% on preloaded Harbor caretaker.
r21 pass 3 results (2026-11-14, prototype; scripted clicks):
- ✓ Cold open, Include items below: preview and result 4 rows in outline order (Cold open with its horn Footage, Ask Dana (checked), Check the crossing board, Gulls over the pier moved); notes stay in Stash, checked; one Undo restores rows, hierarchy, footage strip and original checks (Ask Dana stays checked)
- ✓ Add clip renders below Add note
- ✓ Night ferry: Find original › verified fixture match restores it (logged 0:12–0:20 kept) as one Undo entry; Undo makes it unavailable again; Replace clip › Harbor mouth replaces it; Undo restores
- ☐ Wrong-file rejection message and Cancel focus return (built; checks timed out)
- ✓ Comments list shows "Gap before “When the harbor… nobody has to wait alone.”"
- ✓ Permissions and Mark all reviewed scope unchanged from r16 (not retested)
- ☐ Gold flash at the destination (built; not observed)
r22 results (2026-11-14, prototype; scripted clicks; the dirty edits were applied to the editor's model directly because scripted typing into the saved-row editor didn't reach it):
- ✓ Root saved row s06 starts at x 976, the checkbox lane is 977 and the root clip is 976
- ✓ Opening saved row s06 shows only that row (no other rows, no section headings) with Stash open
- ✓ Clean switch s06 → s08 opens s08 directly
- ✓ Dirty switch: the prompt appears with the pending item; Keep editing stays on s08 with its edit and clears the pending switch; Don't save discards s08's edit and opens s06; Save stores s06's edit (one Undo entry, "Saved the row in Stash") and opens s08
- ✓ (Codex, Chrome) Wrong-file rejection shows "Nothing changed"; Cancel returns focus to Find original…
- ✓ (Codex, Chrome) Real typing in a saved row → dirty-switch prompt; Keep editing keeps the draft; Don't save opens the requested row
r23 results (2026-11-14, prototype; synthetic pointer drags, rendered-state sampling every 150 ms):
- ✗→✓ Inline drop of "Hold on the bell rope…" into s05: before the fix, a whole text span (including surrounding words) was tinted or nothing flashed; after it, gold overlays sit on exactly the 9 inserted words ("Hold … line.") and are removed after about 1.25 s
- ✓ Branch drop of Cold open between rows: 4 rows inserted; all four rows' text turned gold (rgba 242 220 156) and then cleared; one Undo removed them
- ✓ Footer reads "Everyone can Resolve, Reopen and Reattach comments."

r24 (2026-11-15, prototype; synthetic events):
- ✓ Still Image in s01 shows Reselect range on hover and on keyboard focus
- ☐ Reselect in ⋯ menu + confirm/Undo/cancel on a Still; trim-editor brackets (drag, ← →); playback scope with Trim open/closed; slider slow-drag/keys; ferry short excerpt "it goes, and the ferry is" and update after a new trim; full-mode highlight; single comment count; row labels; Add note ▾ Add clip; group placement skipping completed (mixed, all-checked → disabled, attached footage, Undo); 6 s popups with hover pause; 1024 × 768 layout — built, not yet checked (usage limit)
r25 Pass 1 (2026-11-15, prototype; synthetic pointer/keyboard events and programmatic selections — not native input):
- ✓ Opening Still (Recipe card): ⋯ stays at the same position with and without hover; Reselect range is a separate button below the header with no overlap; clicking ⋯ opens the menu (Rename…, Reselect range, …) and doesn't start Reselect — 1280 × 800 and 1024 × 768
- ✓ ⋯ › Reselect range, focus the active control, Escape: mode ends, brackets unchanged, "Reselect cancelled…", focus returns to ⋯ (1280) / the Reselect button (1024)
- ✓ Confirmation: 22 highlight boxes across 3 wrapped lines for a 22-word span; old brackets unchanged while open; highlight cleared on Set range/Escape
- ✓ Recipe Card shorten (Still 1 → "The cook … the room."): 1⟧ moves before "One note", ⟦2 unchanged, "↩ OC resumes", no Still Image 1 resumes; one Undo restores the original sequence
- ✓ Cutaway inside Still 1 (Still 2 → 11 words in Still 1): "Still Image 1 resumes" correct; then shortening Still 1 before it: the confirmation names "Recipe card no longer resumes after it"; Escape keeps the prior sequence
- ✓ Dialogue Footage (Harbor mouth in the opening row): Reselect → 9-word span highlighted, Set range moves it and Still 1 resumes after; one Undo restores all brackets
- ✓ (Codex, Chrome) ⋯ click; Escape → focus on ⋯; one-word commit + Undo at 1280; compact Escape keeps brackets
- ✗→✓ Keyboard Reselect (Codex repro): after the fix, 6 word-extensions show "1…6 words selected · Enter to review", with no confirmation and no selection toolbar; Enter opens "6 words" with 6 highlight boxes; Set range commits exactly "The cook who wrote it had" (6 words); Undo restores. At 1024 × 768: 8 extensions, no toolbar, Enter → confirmation, Escape cancels with the brackets unchanged and focus on ⋯ [synthetic keyup + Selection.modify]
- ✓ Pointer selection: release opens "10 words" with 10 highlight boxes, no toolbar; extending during the confirmation changes nothing; Set range commits 10 words
- ✓ (Codex, Chrome) r25 six-word keyboard review, Set range, one Undo at 1280; compact Escape
r26 Pass 2 (2026-11-15, prototype; scripted clicks/keys, simulated media and fixture/simulated word timings):
- ✓ Two uses of Harbor mouth: the cards show different in-trim words; extending use 1's out point to 6.0 s updated only use 1's transcript; the panel preview trim (5.0–9.0 s) was unchanged
- ✓ Player opens 520 px wide at 1280; the transcript box grows up to 210 px
- ✓ Panel, Short transcripts on: Channel light (logged 1.2–7.4 s) shows "it goes, and the ferry is" highlighted; caretaker clip with no trim shows the opening with "…" and Show full transcript; whole clip explicitly selected shows all 307 characters highlighted, "Whole clip selected", no button, in both modes
- ✓ Quiet piano: ⌈♪ in "The amber lantern…" and "♪ Quiet piano⌋" in "A chalk crescent…", visible; no purple rail; new cue "Harbor Tide Bed": Undo label, trim label, panel name and accessible names show no Mn IDs
- ✓ Hide completed hides checked Gulls; Cold open branch with all items checked: Place in script… disabled, grey, "every item here is completed"
- ✓ (Codex, Chrome) Hide completed hides checked Gulls; mixed Cold open places 2 rows with horn footage + one Undo; Place disabled for all-completed branch; exact Channel light short text; wider player opens at 1024 × 768
- ✗ (Codex) 1024 × 768 with Contributions bar: bar covered/intercepted the trim transcript; player extended below the frame → fix built (post-render clamp to frame, above the bar, internal scroll)
- ☐ Player inside frame and above the bar at 1280 × 800 and 1024 × 768 — not verified (preview unresponsive to checks this session)
- ☐ Overnight regressions; six-word keyboard smoke in r26 — not run
r27 (2026-11-15, prototype; scripted clicks/keys and synthetic mouse drags — no native pointer; simulated media):
- ✓ Workshop recording player: rows don't overlap at 1280 and 1024; with the Contributions bar visible at 1024 the player is at 277–717 × 12–647, inside the frame and above the bar (top 655), and scrolls internally
- ✓ Trim drag (synthetic mousedown/move on the in handle): player top stayed at 12 px through 8 moves and after release
- ✓ Paper Lanterns: "Each one…show through." and "board…the" each give Still 1 · On Camera · Still 2 with no extra "OC resumes"; one Undo restores the original brackets
- ✓ Quiet piano: no row badge; ♪⌋ in text; "♪ Quiet piano ends" shown outside the narration on focus and hover
- ✓ Harbor door ⋯ › Add audio starting at this row’s start: Harbor Tide Bed face on the row, end in the next row, hold stays 4.0 s, Match audio duration offered; one Undo
- ✓ Footage card: header above a full-width transcript; no arrows or trim notes; "Used 3 times" lists rows 25–27 and each jumps there; Place in script… appears on keyboard focus, places one visuals-only row, one Undo
- ☐ Real framing change across a row break; narrow panel width; reload check of the cue label
- ✓ (Codex, Chrome) Workshop: no overlap; real out-handle drag 22.0→18.6 s (1280) and 18.2 s (1024) with bounds unchanged, restored; three-use list; keyboard gap placement + Undo; Harbor Tide Bed on Harbor door keeps 4.0 s and continues into "Rain gathers along the window"
r28 (2026-11-15, prototype; synthetic pointer events):
- ✗→✓ Pointer drop of Workshop recording on the line below Harbor door: before the fix, no target (the seam strip covered the line); after, the ghost reads "New visuals-only row here" with a 6 px gold line, and one row is inserted between Harbor door and Rain gathers; one Undo removes it — title drag at 1280, thumbnail drag at 1024
- ✓ Drop onto Harbor door's visual: "Add to this row", the visual is added; one Undo
- ✓ Harbor door ⋯ › Add audio: picker reads "starts at the start of “Harbor door”"
- ☐ Ending a cue at a visuals-only row boundary: not possible in the prototype model; moved to working-app acceptance
r29 (2026-11-15, prototype; scripted fixtures through the component plus rendered-DOM reads at 1217 × 747; no screenshots, no real pointer):
- ✓ Harbor mouth (trim 5.0–9.0 s): before, during "mouth" and after clearing, identical in both modes — Short: only "just after the turn, … starts to slide"; full: whole transcript with that passage marked; "Used 3 times" pill kept
- ✓ No [data-qpline] stripe in Authoring on a clean load; Quiet piano ⌈♪ … ♪⌋ brackets present
- ✓ "♪ Quiet piano ends": shows on keyboard focus, clears after scripted .blur(); shows on pointerover, clears on pointerout
- ✓ Raincoat still → whole row: both On Camera cards gone (one card left); narrowed back to its words, then whole again: no leftover OC; narrowing gives OC · Still · ↩ OC resumes; 3 Undos restore the original
- ✓ Workbench, Still 1 from "little tin…": full On Camera card · Still 1 · On Camera · Still 2 (no compact chip first); one Undo restores
- ✓ Chalk crescent split before "The shape simply marked…": second row is one On Camera card (the original, Wide) · slate still; one Undo restores the row count and visuals
- ✓ Paper Lanterns "Each one…through." and "board…the": On Camera · Still 1 · On Camera · Still 2, ranges contiguous; one Undo each restores
- ☐ 1024 × 768 and 1280 × 800 frame checks; native-pointer Reselect and Tab split; a newly added cue's brackets and label
- ✓ "A folded letter…": dragging Still 1's ⟧ to the last On Camera word removes On Camera (Still 1 · Still 2); Reselect over the same words does the same (scripted; superseded by the review failures below)
r29 review failures (2026-11-15; open for implementation in one production range-edit issue):
- ✗ Folded Letter: dragging the bracket removed On Camera, but Undo stayed disabled
- ✗ Folded Letter: shortening the still by one word moved the neighboring still's start
- ✗ Amber Lantern and Paper Lanterns: confirming the highlighted selection created an Undo entry while the displayed brackets stayed put
Production acceptance for that issue:
- ☐ After a bracket drag, keyboard bracket move or confirmed Reselect, the displayed brackets, cards and On Camera passages match the confirmed edit
- ☐ Shortening a visual by one word changes only that visual's end and hands the freed word to On Camera; the neighbour's start doesn't move
- ☐ Removing On Camera by a bracket drag creates one Undo entry; that Undo restores On Camera with its framing
- ☐ One Undo restores the full prior sequence (every range, On Camera passage and framing, card order) on Folded Letter, Amber Lantern and Paper Lanterns
- ☐ The first On Camera in each row is full-size, even after a still; a compact card appears only for a return after an intervening cutaway
- ☐ Untrimmed clip during a search shows the ordinary excerpt (code path unchanged; not exercised)
- ☐ Adding Footage opens quick search with the cursor in the box; typing filters on title and transcript
- ☐ Clips whose transcripts match the selected words appear first, with the matching words listed
- ☐ Enter in the search box picks the top clip; ↑/↓ move through results; Esc closes
- ☐ Unused clips only by default; Show used reveals used clips, marked as used
- ☐ Works smoothly with 100+ clips
- ☐ Show footage panel lists all footage with a detailed search and its own thumbnail slider
- ☐ Clicking a used clip scrolls to its placement; a clip used 3 times steps 1/3, 2/3, 3/3
- ☐ Dragging a clip from the panel into a row lands it unattached
- ☐ Re-trimming a clip, deleting that instance, then placing the clip again uses the new trim; other instances keep theirs
- ☐ Unavailable clips place and show recovery options

**Sections (script)**
- ☐ Add section inserts a break between rows with an inline title field
- ☐ A break can't be placed mid-row
- ☐ Section ⋯ › Rename works; Delete break merges into the previous section; Undo restores it
- ☐ Exported markers match section titles and positions

**Stash**
- ☐ The count and header breakdown match after every add, delete, place and return
- ☐ Notes keep literal brackets through save, place, return and export
- ☐ Placing a note creates spoken text and checks the original; Hide completed works
- ☐ An untouched copy returns and unchecks the source only if that insertion checked it
- ☐ Attached footage: Replace keeps the old clip as a child; Detach and Undo work; blanking the text keeps the footage
- ☐ Dragging a note into a row shows a gold text cursor between words, never inside a direction
- ☐ Dragging a clip onto the visuals side shows a gold line between cards
- ☐ The drag ghost never covers the gold text cursor or insertion line
- ☐ Stash words: plain words become a note; words with cues become a saved row
- ☐ Completed notes show the gold drop line when dragged (D83 retest)
- ☐ Saved row and group editors: Save, Cancel, ask on close, add and remove rows in a group
- ☐ Returns go to the original place, or the top of Stash when it's unclear
- ☐ Rename a Stash section; deleting one moves its items to unsorted at the top, keeping order and nesting
- ☐ Delete is one click, and Undo restores it

**Comments**
- ☐ Yellow words open their discussion
- ☐ In Sorting, comments show in the sidebar (Show footage hides; Footage switches to Stash); clicking one expands its row and scrolls to it; clicking another collapses the first

**Sorting**
- ☐ Accept/Discard work; Undo history survives Sorting
- ☐ Show contributions hides in Sorting; Stash stays

**Show contributions**
- ☐ Chips use first names; Since last reviewed omits You
- ☐ The green pill appears only when the bar opened itself
- ☐ Removed rows show in the Reconciliation format with a typed visual
- ☐ Show removed default follows the range

## Research lists pilot (R8-1 to R8-3) · 2026-11-19
File: `VERA Research r6 - Lists pilot.dc.html`, built on the frame `Lists Pilot Frame.dc.html`. r6 is unchanged.
**Test checklist:**
- Library is sorted by the selected sort, with kinds interleaved. All clears search, Kind, Label and activity filters but keeps the sort, and announces the reset.
- Mine leaves out Maya's Q-0007. Only clip rows have an export checkbox. The selection count says "N clips selected (M not shown)".
- The S-0003 still preview opens on hover and on keyboard focus without changing row heights. Enter or Open opens the detail view.
- Docked detail is 600px at 1280. At 1024 it opens full width with Back. Excerpt and source are 14px apart, and labels and values are 14px apart.
- Sources has Status and Kind. The keyword picker is a searchable multi-select that matches any keyword, and says how many sources weren't scanned. Hide on a web page asks for confirmation, keeps its Library items, and can be restored from Show hidden.
- Settings section titles are #f2efe8, names #e7e4dd, secondary text #c3c8d0 (all at least 10:1 on #171a20).

## Research capture pilot (R9-1 to R9-3) · 2026-11-19
File: `VERA Research r6 - Capture pilot.dc.html`, built on the frames `Article Capture Frame`, `Video Capture Frame` and `Typed Quote Frame`. Each frame has a fixture switch, "Next save fails".
**Test checklist:**
- Article: images are off by default and the checkbox reads "Show images (2)". Turning it on or off keeps the search and the selection. Pictures is collapsed, and Save still has a failure path and Retry.
- Article: a native selection that starts or ends mid-word snaps out to whole words, and punctuation inside the selected words is kept. The keyboard path is ←/→, Shift+←/→ and Shift+Alt+←/→. Q logs when focus isn't in a text field.
- Every quote path has optional Quoted person and Role or title, kept separate from Author/byline and never filled from it. They can be edited on the saved item, and the edit is recorded in its audit line.
- Video: an invalid In or Out turns off Preview, Log and Copy, and nothing is saved. A typed value snaps to the nearest word edge, the field is rewritten with the snapped value, and the screen reader hears the snap. The receipt shows the exact saved bounds.
- Failed saves keep the draft and show an inline Retry. Retry creates exactly one item. Previewing a saved clip leaves the draft alone. A no-speech range needs a description.
- Typed drawer: starts blank with New source selected. Existing source fills read-only fields labelled "from source". Switching sources, or going back to New, says what was replaced or cleared. There's a single Quoted person field. Esc closes the drawer and returns focus to "+ Type a quote".
**Open:** real key presses and real mouse text selection; the typed drawer at 1024; how Library search covers quoted person on the new items.

## Research capture pilot (R9-1 to R9-4) · 2026-11-19
File: `VERA Research r6 - Capture pilot.dc.html`, which loads the frames `Article Capture Frame`, `Video Capture Frame` and `Typed Quote Frame`.
**Passed (scripted, 1280 and 1024):**
- Article: an exact selection that leaves out a comma, and one that leaves out an opening “, give the same text in the highlight, the rail, the copied text and the logged item.
- Article: logging with Q, a failed save that keeps the selection and quoted person, a double-clicked Retry that creates one item, and editing the quoted person after logging.
- Article: turning Show images on and off keeps the search and the selection.
- Video: the copied text has the excerpt or description, In – Out with length, the title and a YouTube link at In. Copy is disabled while Out is invalid.
- Typed drawer: blank start; Book, then Report, then New source leave no stale fields; a failed save keeps the draft; a double-clicked Retry adds one Library item; the receipt names the item.
- Typed drawer at 1024: the form scrolls and the footer stays in view.
**Open:**
- Real key presses and mouse drags.
- Real clipboard writes, which this preview blocks.
- Real image retrieval: Save still is fixture only.
- Typed-drawer switching and retry were rerun only at 1280 after the preview froze.

## Research Web/Desktop pilot (R10-1 to R10-3) · 2026-11-19
File: `VERA Research r6 - Web Desktop pilot.dc.html`, which loads `Media Pilot Frame` and `Desktop Preflight Frame`.
**Passed (fixture, scripted):**
- In all three contexts the RC-0160 record shows its excerpt, range, citation and comments, and Copy item link gives the item URL.
- Only Alex's Mac shows a file path and Relink. A wrong file (4:40) is refused. The right file (6:05) relinks.
- A teammate's Ask Alex posts a comment that mentions Alex.
- The 1024 Back to Library returns focus to the row.
- The Web handoff has no export controls. Opened, unavailable and unauthorized each move focus to the result message, and Dismiss returns focus to Open in Desktop.
- The CSV control is labelled as the project clip log.
**Needs proof against the real product:**
- Desktop's real deep-link and open behavior, and the account check.
- Real file relink and fingerprinting.
- Comment notifications.
- Real clipboard writes.
- Desktop's real preflight checks.
- The CSV endpoint, which is the existing project-scoped flow.

## Research capture redesign r7 (R11-1 to R11-10) · 2026-11-19
File: `VERA Research r7 - Capture redesign.dc.html` (static mocks), which loads `Capture Frame r7` (kind = article | video, compact). r6 is unchanged.
**Current state:** static. It shows the selected state at 1280 and 1024 for both kinds. Nothing is interactive yet.
**Unscoped NEW:** keyword matching on article text (stems and phrases); deriving transcript chunks from word timings (R11-10); scrolling a logged item into view and flashing it.
**Test checklist (when made interactive):**
- ☐ Dragging in the article or the transcript snaps to whole words, and the highlight is r29 blue on white
- ☐ Clicking outside the text clears the selection, and the rail tools go disabled at full size
- ☐ Video: a drag sets In and Out, and the nudges move by one word
- ☐ Keyword chips show their counts, and clicking a chip jumps to the next hit
- ☐ The logged list scrolls by itself while the tools stay pinned. Clicking an item scrolls to it and flashes it, and on video it also plays the range
- ☐ No item IDs appear in the text. Gold marks your passages and dotted gray marks teammates' passages
- ☐ No transcript chunk is under 15 s or over 40 s unless a pause of 2 s or more or the end of the source forces it, and no chunk splits a sentence

## Research capture prototype r8 (R11, R12) · 2026-11-19
File: `VERA Research r8 - Capture prototype.dc.html` (Video and Article, at 1024 and 1280), frame `Capture Frame r8` (kind, compact, chunkMin).
**Current state:** working prototype. Saving, playback and the clipboard are simulated, and the data is a fixture.
**Passed (scripted pointer and keyboard events, not a physical mouse):**
- ✓ A drag starting mid-word snaps to the whole word. The highlight is continuous across spaces and across two transcript chunks.
- ✓ A click without a drag clears the selection.
- ✓ Out › and In ‹ nudge by one word, and the In/Out fields and word hints update.
- ✓ Log clip and Log quote (Q) add the item in position order, flash it and scroll the list to it, and clear the selection. The new passage shows a gold underline.
- ✓ Clicking a saved clip scrolls the transcript (scrollTop checked) and plays the range, and the player shows its time and the logger.
- ✓ Clicking the Bus shelter chip twice goes to 1/2, then 2/2.
- ✓ Shift+→ selects by word.
- ✓ The comment chip opens the full comment.
- ✓ At 1024, with a long selection and 6 saved clips, the player, In/Out and Log stay in view.
**Not checked:** a real physical drag (including auto-scroll while dragging past the edge), screen-reader output, typing a time in the field, the no-speech description path, Show images, and Save still.
**Unscoped NEW:** literal keyword matching on article text, deriving chunks from word timings, scrolling a passage into view and flashing it, and source comments in the source bar.

## Research capture prototype r9 (R13) · 2026-11-19
File: `VERA Research r9 - Capture prototype.dc.html`, frame `Capture Frame r9`.
**Current state:** working prototype. Saving, playback (a simulated clock with no media), volume and the clipboard are simulated.
**Passed (scripted pointer and keyboard events at 1024 · 768):**
- ✓ The browse state shows the player plus 6 saved clips, newest first, with no form.
- ✓ Click the scrubber into the silence, then K, I and O: the form opens with "No speech", a required description and Log disabled. After a description, Log puts the clip at the top of the list and focus returns to the reader. Typing "i" in the description doesn't mark In.
- ✓ A long transcript selection across 4 chunks: the excerpt scrolls on its own and Log stays visible.
- ✓ Keyboard: arrows move to the no-speech block and Enter selects it (In 1:42.7, Out 2:02.7).
- ✓ Article: a quote across two paragraphs, Q logs it to the top, and the list scrolls with 5 items. Keyword chips match the bold text (Bus shelter 2, Council 2).
**Not checked:** the 1280 frames were not exercised, and there was no physical mouse or screen reader. Not checked by script: dragging the scrubber, J and L, volume, Show all by keyboard, and search previous/next.
**Unscoped NEW:** a real player with I/O marks, snapping a mark to a word edge, and per-source newest-first ordering.

## Research walkthrough r10 (R14) · 2026-11-20
File: `VERA Research r10 - Walkthrough.dc.html`. Each frame has a checklist of 6 steps that ticks as you go.
**Current state:** working prototype. Saving, playback, fetching text for added sources and copying are simulated. Only the Fairmount article and the reflective-roofs video open in capture.
**Passed (scripted pointer and keyboard events):**
- ✓ 1280: added a source with a reason, and it appears at the top of Sources with "Why added".
- ✓ 1280: opened Maya's article and her reason chip shows by the title. Logged a quote with Q, View in Library selected Q-0012 in the docked detail, then the Kind: Quotes filter plus Open source at ¶1 opened the article from Library, and "← Library" brought back the filter and the selection.
- ✓ 1024: on the video, scrubbed into the silence and used K, I and O. The marks kept exact times (1:45.6 and 1:48.0). C with no description did nothing, and C typed in the description field didn't log. After a description, C from the scrubber logged RC-0153, and View in Library opened the full-width detail.
- ✓ 1024: Open source at 1:45.6 played the range, then "← Library" returned to the detail.
- ✓ 1024: scrolled the list to 420 px and opened RC-0130, then went to the source and back twice. The list came back at 420 px and focus returned to RC-0130. On reopen, the transcript scrolled to 432 px.
**Not checked:** a physical mouse or a screen reader, and the restore after a long session.
**Unscoped NEW:** the add-source reason as the first comment, "View in Library" after logging, and restoring Library state when coming back.

## Research walkthrough r11 (R15) · 2026-11-20
File: `VERA Research r11 - Walkthrough.dc.html`. The test harness is `_r11 harness.dc.html`. Screenshots are in `screenshots/r11/`.
**Current state:** working prototype. Saving, playback, fetching text and copying are simulated. Sources you add stay at Text pending.
**Passed (scripted pointer and keyboard events):**
- ✓ 1024 at 150%: Sources reflows to stacked rows.
- ✓ 1024 at 150%: added a source with a long URL and a Why this? note. It shows Text pending with the note. Opened it, edited the note, and the attribution changed to "Last edited by you · Just now".
- ✓ 1024 at 150%: in Library filtered to Stills, the thermal still's preview appears on keyboard focus and the rows don't move.
- ✓ 1024 at 150%, video with the long title wrapping to 2 lines: selected about 135 words across 4 chunks. The excerpt scrolls and the Log row stays in view. Logged with C.
- ✓ 1024 at 150%: View in Library opened RC-0153 in full-width detail with "Outside your current filters (Kind: Stills)". Open source at… played the range, then ← Library and ← Back to Library returned to the Stills list.
- ✓ 1024 at 150%, article: a 120-word quote scrolls in the excerpt, and Log quote · Q stays in view.
- ✓ 1280 at 100%: detail is docked.
- ✓ 1280 at 150%: detail goes full width. Opened RC-0130 after scrolling the list to 380 px, went to its source and back twice. The list returned to 380 px with focus on RC-0130.
**Not checked:** a physical mouse or a screen reader, posters from real footage (the fixture has none, so every footage slot shows the filmstrip fallback), and 1280 at 135–145%.
**Unscoped NEW:** editable shared source notes with last-editor attribution, the text-size preference across Research views, and still previews on hover or focus.

## Research breadth review r12 (R16) · 2026-11-20
Entry point: `VERA Research r12 - Review.dc.html`. The ledger is `VERA Research r12 - Coverage ledger.md`.
**Passed (scripted events, 1024 × 768 frame, Desktop):**
- ✓ At 150%, Sources reflows with the poster fixture and the moment count shown.
- ✓ The Why this? counter appears, and 205 typed characters are cut to 200 with the limit message.
- ✓ Chrome: edited Why this?, then saved. The receipt credited the edit to you as last editor.
- ✓ Saved a moment at 1:46 with a note. Restoring the draft brought back the note and the frozen time while the video played.
- ✓ Saved a second moment at 2:07 with no note.
- ✓ Open source in Research went to the same video. Moments shows 2 and the 3 earlier comments.
- ✓ Start clip here set In 2:07.0. Out was set with O, and the clip was logged with C. Library went from 17 to 18.
- ✓ The silent-range moment required a description before Log.
- ✓ At 150% the transport stayed at the top of the rail and Log at the bottom (Log at 483–513 px inside a rail ending at 525). These positions were read from the page, not from screenshots.
- ✓ Logic checks run without the page, for both Desktop and Web: Export… vs Open in Desktop, Add · File on Desktop vs Web, Text not found, a new video's first save, and saving to another project.
**Not checked:** the 1280 frame in a browser, a physical mouse or a screen reader, the Web switch in a browser, and the #75 issue body.
**Unscoped NEW:** moments as navigation points with a link to their clip, the 200-character limit message, the sticky transport, the Add tabs, and the extraction-failure view.

## Research final review r13 (R17) · 2026-11-20
Entry point: `VERA Research r13 - Final review.dc.html`.
**Passed (scripted logic run):**
- ✓ The typed drawer binds to s11. An empty save is refused. The exact text, with curly quotes and an em dash, is stored.
- ✓ Two quotes were saved to s11 with the source count unchanged.
- ✓ Library detail shows the provenance fields.

**Not yet run:**
- A browser pass of r13 at both widths.
- Re-checking focus on reveal, close and back, and no items and no matches.
- Web in the 1280 frame.
- A screen-reader pass.
- Generating the standalone export.

## Research final review r14 (R18) · 2026-11-20
Entry point: `VERA Research r14 - Final review.dc.html`. Harness: `_r14 harness.dc.html`.
**Current state:** working prototype. Saving, playback, extraction, export, read state and script uses are simulated.
**Passed (browser, scripted events):**
- ✓ 1280: pinned typed form → Save and add another (focus to quote) → Save (focus to new quote); stale message removed.
- ✓ 1280: quoted person added after logging; Add · Typed article with only title and quote opens the source with the quote focused.
- ✓ 1280: RC-0152 Play runs In → Out; Export preset change and Start export; closing RC-0131 clears "1 new".
- ✓ 1280: item Hide → Undo; Delete on a used item offers Hide instead; Show hidden → All; Delete unused; Clear search focuses Search Library.
- ✓ 1024 at 150%: Moments jump link, cue stays paused, Start clip here sets In; Sources Hide → Undo → Show hidden.
- ☐ Clicking anywhere on a Sources row opens it; Hide doesn't (R18-13).
**Not run:** Web · limited; 1024 at 100% and 1280 at 150%; screen reader; real pointer selection.
**Unscoped NEW:** project-wide hidden state for Library items and its effect on Authoring pickers and existing uses; delete guarded by script uses; per-user comment read state; typed article citation fields; editing quoted person after logging; export destination and preset choices in Library.

## Timeline #642 · S03 r30 B pilot (Q200 quote placement) · 2026-11-21
File: `S03 r30 B Pilot.dc.html` (option B, labeled target). Export: `exports/issue-642-r30b/S03 r30 B Pilot - export.html`.
**Current state:** quote Q-0031 in the Library can be inserted at a sentence boundary as spoken words, or attached to selected words with the narration unchanged. Both add the article picture (primary visual) and a quote box on the same words, as one Undo. Paths: drag, Place in script… and ⌘⇧F.
**Unscoped NEW:** word-level Place in script… (D132/D184 offer only row gaps); a quote box layered over a picture; ⌘⇧F with a caret; sentence-boundary detection in production text.
**Test checklist (scripted pointer and keyboard events, 1280 × 800 and 1024 × 768):**
- ✓ Click between “gauge.” and “The”, then Place in script…: the dialog offers Insert quote before “The comparison matters…”, focus is on Insert quote, and the tag sits above the narration clear of the words.
- ✓ Enter inserts the quote. The narration and the quote box card show the same wording, and the picture and box both cover the 12 inserted words. Focus moves to the picture card.
- ✓ One Undo (button or ⌘Z) removes the words, the picture and the box.
- ✓ Hand-select the whole first sentence and drag the quote onto it: the outline stays on the 13 words, the label reads “Attach quote · narration unchanged” above the text, and the selection toolbar is hidden.
- ✓ Drop attaches both visuals to words 1–13 and the narration is unchanged. One Undo removes both.
- ✓ Moving off the target before dropping, or Escape mid-drag, leaves the script unchanged and the selection in place.
- ✓ Dragging with no selection never attaches.
- ✓ ⌘⇧F with the sentence selected opens Attach quote with focus on the quote; Enter places it; Escape returns focus to the text with the selection restored. With a caret at a boundary it opens Insert quote; inside a sentence it doesn't open (screen-reader message only).
- ✓ Place in script… shows a 2 px focus outline. Escape closes the dialog and returns focus to it.
- ☐ A physical mouse and trackpad, a real Tab order and a screen reader.

## Timeline #642 · S03 r30 B pilot r2 (corrections) · 2026-11-21
File: `S03 r30 B Pilot r2.dc.html`. Export: `exports/issue-642-r30b/S03 r30 B Pilot r2 - export.html`. Checks: `r30b-checks.js` (harness button “Run scripted checks”, or `import("./r30b-checks.js").then(m => m.runAll())`; results panel and `console.table`).
**Current state:** as the B pilot, plus blank-row insert, the drag text guard, single-commit Enter, visible invalid-target notes, Undo clearing the announcement, and dialog placement clear of the quote card.
**Unscoped NEW:** blocking text input while a placement is open; quote placement in any row (Place in script… and drag).
**Test checklist** (72/72 pass: 24 checks at 1280 × 800, at 1024 × 768, and at 1280 × 800 again after resizing; all scripted events):
- ✓ P1 blank row: Add row focuses the blank narration; Place in script… offers Insert quote in the new row; Enter fills the row with the quote; box preview matches; picture and box cover words 1–12; one Undo restores the blank row and clears the announcement.
- ✓ P2 sentence drag: outline and label hold on the selection, label clear of text; drop attaches to words 1–13 with narration identical in data and on screen; one Undo removes both.
- ✓ P3 off-target drop, P4 Escape mid-drag, P5 no selection: script unchanged.
- ✓ K1 ⌘⇧F on the sentence: Attach; Escape restores focus and selection; reopen + Enter twice commits once, no paragraph break.
- ✓ K2 ⌘⇧F at a boundary: Insert; Escape; reopen + Enter commits once.
- ✓ K3 ⌘⇧F inside a sentence: visible note, nothing opens.
- ✓ K4 Place in script…: focus outline; opens clear of the card; Escape returns focus; reopen + Enter twice commits once.
- ☐ Physical mouse and trackpad (especially the full-sentence drag), real Enter/Space on the button, divider-hover Add row, screen reader.

## Timeline #642 · S03 r30 B pilot r3 · 2026-11-21
File: `S03 r30 B Pilot r3.dc.html`. Export: `exports/issue-642-r30b/S03 r30 B Pilot r3 - export.html`. Checks: `r30b-checks-r3.js` (harness “Run scripted checks”, or `import("./r30b-checks-r3.js").then(m => m.runAll())`).
**Current state:** r2, plus a quote drop on a row divider that creates a new narration row (r29 insertion line, “Insert quote as new row”), and spoken quotes wrapped in one pair of “ ” wherever a quote is inserted into narration.
**Unscoped NEW:** quote-to-new-row at a divider; automatic quotation marks on inserted spoken quotes.
**Test checklist** (91/91 pass: 30 checks at 1280 × 800, at 1024 × 768, and at 1280 × 800 again after resizing, plus U1; all scripted events):
- ✓ P6a over the divider below “Across the channel”: 6 px gold line at the divider, ghost reads “Insert quote as new row”, no caret or range cue.
- ✓ P6b drop: one new narration row at that divider; narration “The west gauge … water.” in one pair of curly quotes; picture and transparent box cover words 1–12; the box keeps the unquoted text; one undo step.
- ✓ P6c “Across the channel” narration and the Channel light shot unchanged; the following row unchanged.
- ✓ P6d one Undo removes the row (rows and blocks as before). P6e off-target drop and P6f Escape: rows unchanged, line cleared.
- ✓ P1c blank row, K2b caret insert, K4d Place in script…: the narration gets the wrapped quote.
- ✓ P2b attach: narration identical, no marks added.
- ✓ U1 existing outer pair not doubled.
- ✓ r2 checks P1–P5 and K1–K4 still pass.
- Note: K4a (focus outline) fails when the browser tab doesn't have focus (`document.hasFocus()` false). It passed in the final run.
- ☐ Physical mouse and trackpad drag onto the divider; footage drop on a divider (code unchanged, not rerun).

## Timeline #642 · S03 Integrated Authoring r30 · 2026-11-21
File: `S03 Integrated Authoring r30.dc.html`. Export: `exports/issue-642-r30-integrated/S03 Integrated Authoring r30 - export.html`; editable source in `exports/issue-642-r30-integrated/source/`. Checks: harness “Run scripted checks” (`r30-checks.js`).
**Current state:** see the 2026-11-21 r30 entry in the decision log.
**Unscoped NEW:** Library quick pick on ⌘⇧F; word-span quote attribution; Library failure states; per-use quote-box editor.
**Test checklist** (scripted only: synthetic pointer and key events; 165 of 169 pass across 1280 × 800, 1024 × 768 and 1280 × 800 after resizing):
- ✓ P1–P6, K1–K4 (r3 flows, now integrated) at all three sizes.
- ✓ S1–S3 shared background, box ranges, one Undo restoring the first range; T1–T2 typed quotes; E1–E3 box editor and attribution; W1–W2 warnings; L1–L5 Library states, search and 0% thumbnails; G1–G3 footage placement, On Camera, Sorting.
- ✗ L6 at 1024: the placed article-picture thumbnail is 54 × 31 px.
- ✗ G4 Stash in the full run, three times (passes on its own).
- ☐ Live pointer and keyboard pass at both sizes; range-handle drag on the picture (checked through data only); reload of the standalone export at 1024.

## Timeline #59 · S07–S11 · 2026-11-21
**Base:** accepted r30 (frozen). Producer decisions are P59-1 to P59-9 in the decision log.
**Built:** `S03 r31 S07-S11.dc.html` is the pilot, corrected after Producer review (P59-14); 74/74 scripted checks at both sizes. The handoff is `S03 r31 S07-S11 handoff.md`.
**In review:** `S03 Integrated Authoring r32 review.dc.html` (`36f1eae6…`), with its standalone `exports/S03 Integrated Authoring r32 review - standalone.html` (`a10ad44f…`). Both cover S07–S11 and pass every scripted check at both sizes. The trial list and proof gaps are in `S03 r32 review handoff.md`.
**Status:**
- **Blocked: S07 demotion (P59-1).** The client doesn't switch to Viewer without a reconnect, refused edits are sent again once Editor access returns, and there's no discard.
- **Proven: S07 removal (P59-2).** The connection closes with 4403 and reconnecting is refused.
- **Proven: S07 Viewer read-only.** Closed role matrix; Viewer changes are refused.
- **Needs proof in #643: Viewer Library (P59-7).**
**Unscoped NEW:**
- A client-side discard of refused edits.
- A live `canEdit` status after a role recheck.
- A Timeline Viewer reading the Research Library.
- The access-ended screen.
**Test checklist (S07, when unblocked; 1280 × 800 and 1024 × 768):**
- ☐ As a Viewer, there is no editing, Insert or range control, no comment compose, reply, resolve or reopen, no checkpoint action, no Preview, Release or settings, and no Library placement action. Each is checked in the accessibility tree and by Tab order, not just hidden or disabled.
- ☐ Demotion mid-typing: the screen switches to Viewer and focus goes to the notice naming the rows. OK discards the edits, and the row shows the saved text. After Editor access is restored, none of the discarded text appears.
- ☐ Removal: the full-page access-ended screen discloses no script content, and no stale handler can make a change.
- ☐ Viewer with no Research permission: r30's access-denied state, no quote text or picture.

## S03 Integrated Authoring r33 · 2026-11-22
File: `S03 Integrated Authoring r33.dc.html`. It builds on the r32 review revision, which stays frozen and unchanged. r33 saves its script under its own browser key. Decisions are in the 2026-11-22 r33 entry of the decision log.
**Current state:**
- **Top bar (2b).**
  - Line 1: the title, then status as plain text: role, sync, Try again (only when saving fails) and presence. View settings is at the far right and holds Authoring size and Thumbnails.
  - Line 2: Undo ▾, Sort rows, History and Show contributions, then the sidebar switch (Library · Stash · Comments) and Build.
  - Ideas is removed. Stash notes and stage directions are unchanged.
- **Drop onto selected words.** Library footage, a stashed clip or visual, or footage attached to a Stash note attaches to exactly the selected words.
  - The selection stays highlighted during the drag: dashed gold when the pointer is elsewhere, solid gold with a tint over the words.
  - Quotes use r30's attach path and leave the narration unchanged.
- **Compare with now.** Inside Compare, a Checkpoint dropdown lists every accessible checkpoint and shows whether each is approved (approval is required for Build). The sample checkpoints are "Approved review cut" (revision 41, approved) and "Cut for Dana" (revision 42, not approved).
- **Build.** A verified Studio timeline completes the build. Render MP4 is off by default. When it's on, Render settings show a named Resolve preset with a summary, and Upload to Drive is a separate opt-in. Free keeps the manual import confirmation.
- **Library count.** An empty Library shows 0. When access is denied, the count is omitted.

**Fixed during checks:** the sync label held a dot element and the label text in one status span with a dynamic style. Opening Library and selecting words then caused multi-second preview stalls. The dot is now a sibling of the label, and the top bar keeps r32's wrapping container. Separately, the preview stalls for about 3.5 s while idle on both r32 and r33, so screenshot runs need waits between steps.

**Unscoped NEW:**
- Attaching a visual to an exact word range in one drop. This needs no new backend beyond the existing attach.
- Comparing any checkpoint against the current revision (the visual comparison is #689/#690).
- Render presets read from Resolve, with which preset settings can be read and shown pending #329.
- A per-build MP4 opt-in, and Drive upload only when an MP4 is rendered.

**r33 checklist (changed items only; 1280 × 800 and 1024 × 768):**
- ☑ Top bar at both sizes, Editor, Sync failed with Try again and presence: neither line overflows. At 1024 there are about 280 px between the status text and View settings.
- ☑ View settings opens below the button and stays inside the frame.
- ☑ Viewer: Viewer · read only, no Undo or Sort rows, and Build results.
- ☑ Library, Stash and Library again: opens, switches and closes with no stall.
- ☑ 1280: dragging Library footage onto the selected words attaches it to exactly those words. Undo removes it.
- ☑ 1024: a stashed clip.
  - Away from the selection: dashed marks, the selection kept, and the hint "or drop on the highlighted words to attach".
  - Over the words: solid marks and the label "Attach to “checks the same” · exactly these words".
  - The drop attaches to exactly those words and clears the marks.
- ☑ 1024: a quote dropped on the selected words: Attach quote Q-0031, narration unchanged.
- ☑ Compare: the dropdown lists both checkpoints with their approval. Switching moves Compare to that checkpoint and keeps focus on the dropdown.
  - The approved and unapproved checkpoints show different results against the same current revision.
  - As Producer, Approve shows only on the unapproved checkpoint.
- ☑ Build, Studio: Render MP4 is off by default and no Render settings show.
  - Timeline only: four stages, then "Build complete. Timeline verified." The past entry reads "Timeline verified".
- ☑ Build, Studio, with Render MP4 and Upload to Drive:
  - The preset dropdown switches its summary.
  - The build runs six stages and shows the MP4 path with its preset and "Uploaded to Drive… Not shared".
  - Render MP4 resets to off after the build.
- ☑ Build, Free: no render options; Ready to import and I’ve imported it.
- ☑ Build and History panels at both sizes: inside the frame, no horizontal overflow, and the dropdowns fit.
- ☑ Empty Library: the count shows 0 and the label is "Library, empty". With access denied, there is no count.
- ☐ Live drags with a physical mouse and trackpad, a real Tab order and a screen reader.
- ☐ `r32-checks.js` against r33. Its Ideas and old top-bar label checks are now obsolete.

## S03 Integrated Authoring r34 · 2026-11-22
File: `S03 Integrated Authoring r34.dc.html`. Successor to r33, which stays unchanged, as does approved Research r14. r34 saves its script under its own browser key. Decisions are in the 2026-11-22 r34 entry of the decision log. Everything not listed here is unchanged from r33.
**Current state:**
- **+ Visual** sits at the foot of the right column on every editable row: narration rows with or without visuals, and visual-only rows.
  - It opens the type menu (Footage first, then On Camera…). Highlight words → Add visual remains the second path.
  - It is hidden for Viewers, during Sort rows, and on rows being edited from Stash.
- **Footer tally.** One line, "N picture changes · N transitions" (it replaces "All cuts" over the cut count), plus a runtime readout: "Est. runtime m:ss (+ N untimed)" over "N spoken words · W wpm manual|measured · m:ss visual-only". Clicking it opens Project settings › Narration pace.
  - Spoken words exclude bracketed directions and nonspoken rows.
  - Estimate = spoken words ÷ wpm + the lengths of visual-only rows. A placeholder's length, or a clip's in→out, counts; anything else is untimed. Visuals over narration add nothing.
- **Project settings** (⚙ beside View settings) is shared by the project. Each item shows who can view and edit it.
  - Narration pace: manual wpm, or Calculate from footage. Pick a sample, then Measure pace, then "Use N wpm". The pace in use is always stated, and the manual pace is the fallback.
  - Delivery: Drive account and default upload folder. A simulate strip switches between Disconnected, Connected with no folder, and Configured. Only a Producer edits it; Viewers see that Delivery is restricted.
  - Render presets are marked "In Resolve". Presenter image, Topics and keywords, Default transitions and Templates are labelled Proposal.
- **Build.** The Render settings note says presets are defined and saved in Resolve (#329). Upload to Drive is enabled only when Delivery is configured. Otherwise Build shows why, with "Set up Delivery…" (Producer) or "View Delivery settings" (others).
- **Header proposal** (separate file, `S03 r34 Header alignment proposal.dc.html`) compares the r34 header with Research r14 at 1280 and 1024 and shows the round trip between the apps.

**Unscoped NEW:**
- A project-level settings store with per-setting role rights.
- Measuring pace from timed transcripts of the narrator's footage.
- A runtime estimate in the footer.
- Delivery (#71): Drive OAuth per project, a default folder, and gating Build's upload on it.
- Listing Resolve presets (#329).
- Cross-app switcher plumbing: a membership check in the destination app, a stored Timeline↔Research project link, a project chooser, and VERA home.

**r34 checklist (changed items only; 1280 × 800 and 1024 × 768):**
- ☑ + Visual is visible on all 28 editable rows for Editor and Producer, and on 0 for Viewer.
- ☑ + Visual opens Footage · On Camera · Still Image… by pointer and by Enter on:
  - a narration row with visuals (nrq30),
  - a narration row with no visuals (s02, simulated by clearing its visuals),
  - a visual-only row (k1).
  - Escape returns focus to the button. With keyboard focus the button is at full strength.
- ☑ Footer, 3,117 spoken words at 150 wpm manual: 20:47 of narration + 0:58 visual-only = 21:44 + 1 untimed (Harbor door).
  - With the pace cleared: "Runtime not estimated · no pace set".
  - Fits at 1024 with no overflow.
- ☑ Pace:
  - Choosing Calculate from footage without a measurement keeps the manual pace and says so.
  - Measure on sample 1 shows 162 wpm (112 words ÷ 0.69 min). "Use 162 wpm" switches the pace in use and the footer to "measured".
  - Switching the sample asks you to measure again. Viewer sees everything read-only.
- ☑ Project settings opens from the gear and from the footer, and closes on Escape. It and View settings close each other.
  - At 1024 it stays inside the frame (405 px from the left edge) and scrolls vertically with no sideways overflow.
- ☑ Delivery: all three states. As Producer, Connect → Choose folder → Configured works; Editor sees it read-only; Viewer sees that it's restricted.
- ☑ Build:
  - Timeline only → "Build complete. Timeline verified."
  - Render + Drive (configured) → MP4 path and "Uploaded … Not shared".
  - Drive disconnected: the upload box is disabled with a reason, and the route opens Delivery with focus on it.
  - No folder, as Producer: "Set up Delivery…"; render without upload still completes.
  - Free: no render options and the import confirmation is unchanged.
- ☐ Header proposal: you decide whether to adopt it, and whether Research's Aa slider moves into View settings.
- ☐ Real keyboard, screen reader and physical pointer pass. The checks above used scripted events in the preview.

## S03 Integrated Authoring r35 · 2026-11-22
File: `S03 Integrated Authoring r35.dc.html`. It builds on r34, which stays unchanged, and saves under its own browser key. The paired header proposal is `S03 r34 Header alignment proposal.dc.html` (updated). Everything not listed here is unchanged from r34.
**Current state:**
- **Header row 1:**
  - VERA ▾ Script to Timeline: the app menu, which opens Research Video Clips in a new tab. A SIMULATE strip inside it switches between 1 linked, 2 linked and none authorized.
  - Project title ▾ with its context line: the project menu, listing Script to Timeline projects with your role on each.
  - Role · sync · Try again · presence, then ⚙ Project settings, View settings and the account (AR).
- **Header row 2:** unchanged from r34.
- The harness has a "Long title" toggle.
- **Project settings:** Narration pace and Delivery, plus a provisional handoff list.
- **Footer:** "N picture changes · N transitions" · "Est. m:ss · excludes N untimed row(s)" over the spoken-word count, pace and visual-only time.

**Prototype limitations:** the r33 Sorting preview and the expanded connector defects (#616; connector case recorded on #59).

**Unscoped NEW:**
- The project menu: an in-app project list with roles.
- Each app's chooser and home for incoming switches.
- The navigation envelope (#13 §5.2).

**r35 checklist (changed items only):**
- ☑ 1024, long title, Sync failed and presence together: neither row overflows. Title (truncated), role, Sync failed, Try again, presence, gear, View settings and account are all inside the frame. Same at 1280.
- ☑ VERA menu by pointer:
  - Opens with focus on Research Video Clips. ↑/↓ move between items.
  - Each simulated case states its destination.
  - Choosing it reports a new tab and an unchanged source tab.
  - Escape returns focus to the VERA button.
- ☑ Project menu: opens with focus on the first other project. Choosing it explains a same-tab switch with membership rechecked. Escape returns focus to the title.
- ☑ Project settings: the gear has the accessible name "Project settings" at both sizes, and only Pace and Delivery are navigable. Escape returns focus to the gear, or to the runtime readout when opened from there.
- ☑ Runtime reads "Est. 21:44 · excludes 1 untimed row". The tally reads "52 picture changes · 0 transitions".
- ☑ + Visual at 1024:
  - The visual-only row k1 opens Footage · On Camera · Still Image, and Escape returns focus to + Visual.
  - All buttons are inside the frame. A Viewer sees none.
- ☐ Visual/screenshot review. My preview timed out on this file, so it's left to the background verifier and to you.
- ☐ Real keyboard Tab order and screen reader (VoiceOver/NVDA): not run. The checks above used scripted events in the preview.

## S03 Integrated Authoring r36 · 2026-11-22
File: `S03 Integrated Authoring r36.dc.html`, with the frozen paired proposal `S03 r36 Header alignment proposal.dc.html`. r35, the r34 proposal file and Research r14 are unchanged. Matthew confirmed his r35 notes were addressed; final sign-off remains his.
**r36 checklist (changed items only):**
- ☑ The VERA menu item and the simulated result say "Research". There is no "Research Video Clips" left in r36 or the r36 proposal.
- ☑ 1024, long title, Sync failed and presence:
  - Hovering or focusing the title shows the full 99-character title, wrapped to 3 lines, below row 1 and inside the frame.
  - The header doesn't move and Try again isn't covered.
  - The accessible name is "Project: [full title]. Switch Script to Timeline project".
- ☑ 1024, presence: "Jonah is editing row 1" and "Jonah edited row 1 · just now" both truncate. Focus or hover reveals the full text below row 1 without covering Try again, and the accessible name is the full string. Escape dismisses it.
- ☑ 1280: presence isn't truncated, so it isn't focusable and shows no reveal. At 1024 the default short title also truncates (181/121 px) and reveals the same way.
- ☐ Real pointer, keyboard and screen-reader pass in the running app (Matthew's stress test).

**Production follow-ups:**
- The tooltip should follow the suite tooltip primitive (#13 §4.3): hoverable, dismissible and persistent.
- Truncation should be measured live on resize.
- The status region should announce presence changes politely without re-announcing on focus.
